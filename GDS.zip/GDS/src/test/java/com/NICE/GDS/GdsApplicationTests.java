package com.NICE.GDS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
