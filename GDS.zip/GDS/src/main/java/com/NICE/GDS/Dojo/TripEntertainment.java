package com.NICE.GDS.Dojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;

import java.sql.Date;

public class TripEntertainment {
    @JsonProperty("TripId")
    private int TripId;
    @JsonProperty("EntertainmentId")
    private int EntertainmentId;

    private Entertainment Entertainment;

    @Column(name = "schedule", nullable = false)
    private Date schedule;

    public int getTripId() {
        return TripId;
    }

    public void setTripId(int tripId) {
        TripId = tripId;
    }

    public Entertainment getEntertainment() {
        return Entertainment;
    }

    public void setEntertainment(Entertainment gdsEntertainment) {
        this.Entertainment = gdsEntertainment;
    }

    public Date getSchedule() {
        return schedule;
    }

    public void setSchedule(Date schedule) {
        this.schedule = schedule;
    }

    public int getEntertainmentId() {
        return EntertainmentId;
    }

    public void setEntertainmentId(int entertainmentId) {
        EntertainmentId = entertainmentId;
    }

    @Override
    public String toString() {
        return "TripEntertainment{" +
                "TripId=" + TripId +
                ", EntertainmentId=" + EntertainmentId +
                ", Entertainment=" + Entertainment +
                ", schedule=" + schedule +
                '}';
    }
}
