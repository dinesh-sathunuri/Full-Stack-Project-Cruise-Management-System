package com.NICE.GDS.Dojo;

import java.time.LocalDate;

public class BookingTrend {
    private LocalDate date;
    private int bookingCount;

    // Getters and setters
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getBookingCount() {
        return bookingCount;
    }

    public void setBookingCount(int bookingCount) {
        this.bookingCount = bookingCount;
    }
}