package com.NICE.GDS.Controllers;

import com.NICE.GDS.Dojo.Booking;
import com.NICE.GDS.Dojo.BookingRequest;
import com.NICE.GDS.Dojo.BookingTrend;
import com.NICE.GDS.Dojo.BookingWithDetails;
import com.NICE.GDS.Services.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/create")
    public ResponseEntity<?> createBooking(@RequestBody BookingRequest request) {
        try {

            // Call the service to create a booking and get the booking ID
            Booking booking = bookingService.createBookingWithTransaction(
                    request.getBooking(),
                    request.getPaymentMethod(),
                    request.getPackages()
            );

            // Construct a response with the booking ID
            return new ResponseEntity<>(Map.of("bookingId", booking.getBookingId()), HttpStatus.CREATED);

        } catch (Exception e) {
            return new ResponseEntity<>("Error creating booking: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/past")
    public List<BookingWithDetails> getPastBookingsByEmail(@RequestParam String email) {
        return bookingService.getPastBookingsByEmail(email);
    }
    @GetMapping("/trends")
    public List<BookingTrend> getBookings()
    {
        return bookingService.getBookings();
    }

    @GetMapping("/packages/popularity")
    public List<Map<String, Object>> getPackage(){
        return bookingService.getPackage();
    }
}
