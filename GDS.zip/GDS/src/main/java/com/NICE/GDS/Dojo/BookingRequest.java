// BookingRequest.java
package com.NICE.GDS.Dojo;

import java.util.List;

public class BookingRequest {
    private Booking booking;
    private List<Package> packages;
    private String paymentMethod;

    @Override
    public String toString() {
        return "BookingRequest{" +
                "booking=" + booking +
                ", packages=" + packages +
                ", paymentMethod='" + paymentMethod + '\'' +
                '}';
    }

    // Getters and Setters
    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public List<Package> getPackages() {
        return packages;
    }

    public void setPackages(List<Package> packages) {
        this.packages = packages;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
