package com.NICE.GDS.Dojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;

import java.time.LocalDate;

public class Passenger {
    @JsonProperty("passenger_id")
    private long passenger_id;
    @JsonProperty("first_name") // Maps "first_name" to "firstName"
    private String firstName;
    @JsonProperty("last_name") // Maps "last_name" to "lastName"
    private String lastName;
    private String email;

    @JsonProperty("date_of_birth") // Maps "date_of_birth" to "dateOfBirth"
    private LocalDate dateOfBirth;

    @JsonProperty("street_address") // Maps "street_address" to "streetAddress"
    private String streetAddress;

    private String city;
    private String state;

    @JsonProperty("zip_code") // Maps "zip_code" to "zipCode"
    private String zipCode;

    private String country;
    private String gender;
    private String nationality;
    private String phone;

    // Default constructor
    public Passenger() {
    }

    // Parameterized constructor
    public Passenger(long passenger_id, String firstName, String lastName, String email, LocalDate dateOfBirth,
                     String streetAddress, String city, String state, String zipCode,
                     String country, String gender, String nationality, String phone) {
        this.passenger_id = passenger_id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.streetAddress = streetAddress;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.country = country;
        this.gender = gender;
        this.nationality = nationality;
        this.phone = phone;
    }

    // Getters and Setters
    public long getpassenger_Id() {
        return passenger_id;
    }

    public void setpassenger_Id(long passenger_id) {
        this.passenger_id = passenger_id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Passenger{" +
                "id=" + passenger_id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", streetAddress='" + streetAddress + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zipCode='" + zipCode + '\'' +
                ", country='" + country + '\'' +
                ", gender=" + gender +
                ", nationality='" + nationality + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    public void setPassengerId(long passenger_id) {
    }

}