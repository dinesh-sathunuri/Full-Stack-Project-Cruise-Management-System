package com.NICE.GDS.Controllers;

import com.NICE.GDS.Dojo.*;
import com.NICE.GDS.Dojo.Package;
import com.NICE.GDS.Services.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips")
@CrossOrigin(origins = "http://localhost:3000")
public class TripController {

    @Autowired
    private TripService tripService;

    public TripController(TripService tripService) {
        this.tripService = tripService;
    }

    @GetMapping("/list")
    public ResponseEntity<List<Trip>> getAllTrips() {
        List<Trip> trips = tripService.getAllTrips();
        return ResponseEntity.ok(trips);
    }

//    @GetMapping("/{tripId}")
//    public ResponseEntity<Trip> getTripById(@PathVariable int tripId) {
//        Trip trip = tripService.getTripById(tripId);
//        if (trip != null) {
//            return ResponseEntity.ok(trip);
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//        }
//    }

    @GetMapping("/staterooms/details")
    public List<StateroomDetailDTO> getStateroomDetails(@RequestParam Long tripId) {

        return tripService.getStateroomDetailsByTripId(tripId);
    }

    @GetMapping("/{tripId}")
    public TripDetailsDTO getTripDetails(@PathVariable int tripId) {
        return tripService.getTripDetails(tripId);
    }

    @GetMapping("/packages")
    public List<Package> getPackages() {
        return tripService.getPackages();
    }
    @GetMapping("package/{packageId}")
    public List<Package> getPackageDetails(@PathVariable int packageId) {
        return tripService.getPackageDetails(packageId);
    }

    @GetMapping("stateroom/{stateroomPriceId}")
    public List<StateroomDetailDTO> getStateroomDetailsById(@PathVariable int stateroomPriceId) {
        return tripService.getStateroomDetailsById(stateroomPriceId);
    }

    @GetMapping("RecentGroup/{email}")
    public List<Group> getGroupsByEmail(@PathVariable String email)
    {
        return tripService.getGroupsByEmail(email);
    }


    @GetMapping("/port/list")
    public List<Port> getAllPorts() {
        return tripService.findAllPort();
    }

    @PostMapping("/insert")
    public ResponseEntity<String> createTrip(@RequestBody Trip tripRequest) {
        try {
            tripService.createTrip(tripRequest);
            return ResponseEntity.ok("Trip created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to create trip: " + e.getMessage());
        }
    }
    @PostMapping("/restaurant/insert")
    public ResponseEntity<String> insertRestaurant(@RequestBody Restaurant restaurant) {
        try {
            tripService.insertRestaurant(restaurant);
            return ResponseEntity.ok("Restaurant added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add restaurant: " + e.getMessage());
        }
    }
    @PostMapping("/entertainment/insert")
    public ResponseEntity<String> insertEntrainment(@RequestBody Entertainment entertainment) {
        try {
            tripService.insertEntrainment(entertainment);
            return ResponseEntity.ok("Entertainment added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add restaurant: " + e.getMessage());
        }
    }
    @GetMapping("/entertainment")
    public List<Entertainment> GetEntertainment()
    {
        System.out.println("in C");
        return tripService.GetEntrainment();
    }
    @GetMapping("/restaurants")
    public List<Restaurant> GetRestaurants()
    {
        System.out.println("in C");
        return tripService.GetRestaurants();
    }
    @GetMapping("/Scheduled/restaurant/{tripId}")
    public List<RestaurantSchedule> GetScheduledRestuarant(@PathVariable int tripId){
        return tripService.getScheduledRestuarant(tripId);
    }
    @GetMapping("/Scheduled/entertainment/{tripId}")
    public List<TripEntertainment> GetScheduledEntertainment(@PathVariable int tripId){
        return tripService.getScheduledEntertainment(tripId);
    }
    @PostMapping("/Insert/triprestaurant")
    public ResponseEntity<String> InsertTripRestaurant(@RequestBody RestaurantSchedule restaurantSchedule)
    {
        try {
            System.out.println(restaurantSchedule);
            tripService.InsertTripRestaurant(restaurantSchedule);
            return ResponseEntity.ok().body("");
        }catch(Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add restaurant: " + e.getMessage());
    }
    }
    @PostMapping("/Insert/tripentertainment")
    public ResponseEntity<String> InsertTripEntertainment(@RequestBody TripEntertainment tripEntertainment) {
        try {
            System.out.println(tripEntertainment);
            tripService.InsertTripEntertainment(tripEntertainment);
            return ResponseEntity.ok().body("");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add restaurant: " + e.getMessage());
        }
    }
    @GetMapping("/stateroom")
    public List<StateroomDetailDTO> GetStateRoomDetails()
    {
        return tripService.GetStateRoomDetails();
    }

    @PostMapping("/stateroomPrice/insert")
    public void insertStateroomprice(@RequestBody StateroomPrice stateroomPrice){
        tripService.insertStateroomprice(stateroomPrice);
        System.out.println(stateroomPrice);
    }

}
