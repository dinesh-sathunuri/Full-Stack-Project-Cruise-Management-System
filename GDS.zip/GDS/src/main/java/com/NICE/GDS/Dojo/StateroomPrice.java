package com.NICE.GDS.Dojo;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

import java.math.BigDecimal;

public class StateroomPrice {
    private Long stateroomPriceId;
    private Long stateroomId;

    private Long tripId;

    private String locationSide;

    private BigDecimal pricePerNight;

    private Integer numUnits;

    public Integer getNumUnits() {
        return numUnits;
    }

    public void setNumUnits(Integer numUnits) {
        this.numUnits = numUnits;
    }

    public Long getStateroomPriceId() {
        return stateroomPriceId;
    }

    public void setStateroomPriceId(Long stateroomPriceId) {
        this.stateroomPriceId = stateroomPriceId;
    }

    public Long getStateroomId() {
        return stateroomId;
    }

    public void setStateroomId(Long stateroomId) {
        this.stateroomId = stateroomId;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getLocationSide() {
        return locationSide;
    }

    public void setLocationSide(String locationSide) {
        this.locationSide = locationSide;
    }

    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    @Override
    public String toString() {
        return "StateroomPrice{" +
                "stateroomPriceId=" + stateroomPriceId +
                ", stateroomId=" + stateroomId +
                ", tripId=" + tripId +
                ", locationSide='" + locationSide + '\'' +
                ", pricePerNight=" + pricePerNight +
                ", numUnits=" + numUnits +
                '}';
    }
}