package com.NICE.GDS.Controllers;

import com.NICE.GDS.Dojo.Group;
import com.NICE.GDS.Dojo.Passenger;
import com.NICE.GDS.Services.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/passenger")
@CrossOrigin(origins = "http://localhost:3000")
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @PostMapping("/api/register")
    public ResponseEntity<String> registerPassenger(@RequestBody Passenger passenger) {
        System.out.println("Received passenger: " + passenger); // Log the entire passenger object
        try {
            String result = passengerService.registerPassenger(passenger);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }

    @GetMapping("/api/check-email")
    public ResponseEntity<String> checkEmail(@RequestParam("email") String email) {
        try {
            boolean isRegistered = passengerService.isEmailRegistered(email);
            if (isRegistered) {
                return ResponseEntity.ok("Email is already registered.");
            } else {
                return ResponseEntity.ok("Email is available.");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log stack trace for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to check email registration. Please try again later.");
        }
    }
    // Send OTP for registration via API
    @PostMapping("/api/send-otp")
    public ResponseEntity<String> sendOtp(@RequestParam("email") String email) {
        if(passengerService.isEmailRegistered(email)) {
            String result = passengerService.sendOtp(email);
            return ResponseEntity.ok(result);

        }
        return ResponseEntity.badRequest().body("Email not registered.");

    }

    // Send OTP for registration via API
    @PostMapping("/api/send-otp-register/{email}")
    public ResponseEntity<String> sendOtpRegister(@PathVariable String email) {
        System.out.println("in C");
        String result = passengerService.sendOtpRegister(email);
        return ResponseEntity.ok(result);
    }

    // Verify OTP via API
    @PostMapping("/api/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestParam("email") String email, @RequestParam("otp") String otp) {
        System.out.println(email+otp);
        boolean isValid = passengerService.validateOtpAndRegister(email, otp);
        System.out.println(isValid);
        if (isValid) {
            return ResponseEntity.ok("OTP verification successful! You are now registered.");
        } else {
            return ResponseEntity.status(400).body("Invalid OTP or registration failed. Please try again.");
        }
    }
    @PostMapping("/api/login")
    public ResponseEntity<String> loginPassenger(@RequestParam String email) {
        if (email == null || email.trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email must not be empty.");
        }
        try {
            boolean isRegistered = passengerService.isEmailRegistered(email);

            if (isRegistered) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Email not registered.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }
    @PostMapping("/api/create-group")
    public ResponseEntity<String> createGroup(@RequestBody Group group) {
        try {
            passengerService.createGroup(group);
            return ResponseEntity.ok("Group and passengers created successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while creating the group: " + e.getMessage());
        }
    }
    @GetMapping("/api/userdetails")
    public ResponseEntity<Passenger> getUserDetails(@RequestParam String email) {
        Passenger passenger = passengerService.getPassengerByEmail(email);
        System.out.println(passenger);
        if (passenger != null) {
            return ResponseEntity.ok(passenger);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
    @PutMapping("/api/update-user")
    public ResponseEntity<String> updateUserDetails(@RequestBody Passenger passenger) {
        try {
            passengerService.updatePassenger(passenger); // Implement this method in the service layer
            return ResponseEntity.ok("User details updated successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update user details");
        }
    }
}