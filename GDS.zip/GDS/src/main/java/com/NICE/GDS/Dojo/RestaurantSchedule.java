package com.NICE.GDS.Dojo;


import jakarta.persistence.*;

import java.util.Date;

public class RestaurantSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "restaurant_schedule_id")
    private Long restaurantScheduleId;

    @Column(name = "schedule_date", nullable = false)
    private Date scheduleDate;

    @Override
    public String toString() {
        return "RestaurantSchedule{" +
                "restaurantScheduleId=" + restaurantScheduleId +
                ", scheduleDate=" + scheduleDate +
                ", mealType='" + mealType + '\'' +
                ", tripId=" + tripId +
                ", restaurant=" + restaurant +
                '}';
    }

    @Column(name = "meal_type", nullable = false)
    private String mealType;

    @Column(name = "trip_id", nullable = false)
    private Long tripId;

    private Restaurant restaurant;

    // Getters and Setters

    public Long getRestaurantScheduleId() {
        return restaurantScheduleId;
    }

    public void setRestaurantScheduleId(Long restaurantScheduleId) {
        this.restaurantScheduleId = restaurantScheduleId;
    }

    public Date getScheduleDate() {
        return scheduleDate;
    }

    public void setScheduleDate(Date scheduleDate) {
        this.scheduleDate = scheduleDate;
    }

    public String getMealType() {
        return mealType;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
}