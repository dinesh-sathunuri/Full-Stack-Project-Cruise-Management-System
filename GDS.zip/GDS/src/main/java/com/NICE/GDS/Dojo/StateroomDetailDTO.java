package com.NICE.GDS.Dojo;

import java.math.BigDecimal;

public class StateroomDetailDTO {
    private Long stateroomId;
    private String type_name;
    private Integer sizeSqft;
    private Integer numBeds;
    private Integer numBathrooms;
    private Integer balcony;
    private String cruiseShipSide;
    private Long stateroomPriceId;
    private Long tripId;
    private String locationSide;
    private BigDecimal pricePerNight;

    private Integer Num_Units;

    public Integer getNum_Units() {
        return Num_Units;
    }

    public void setNum_Units(Integer num_Units) {
        Num_Units = num_Units;
    }
// Getters and Setters

    public Long getStateroomId() {
        return stateroomId;
    }

    public void setStateroomId(Long stateroomId) {
        this.stateroomId = stateroomId;
    }

    public String getType_name() {
        return type_name;
    }

    public void setType_name(String type_name) {
        this.type_name = type_name;
    }

    public Integer getSizeSqft() {
        return sizeSqft;
    }

    public void setSizeSqft(Integer sizeSqft) {
        this.sizeSqft = sizeSqft;
    }

    public Integer getNumBeds() {
        return numBeds;
    }

    public void setNumBeds(Integer numBeds) {
        this.numBeds = numBeds;
    }

    public Integer getNumBathrooms() {
        return numBathrooms;
    }

    public void setNumBathrooms(Integer numBathrooms) {
        this.numBathrooms = numBathrooms;
    }

    public Integer getBalcony() {
        return balcony;
    }

    public void setBalcony(Integer balcony) {
        this.balcony = balcony;
    }

    public String getCruiseShipSide() {
        return cruiseShipSide;
    }

    public void setCruiseShipSide(String cruiseShipSide) {
        this.cruiseShipSide = cruiseShipSide;
    }

    public Long getStateroomPriceId() {
        return stateroomPriceId;
    }

    public void setStateroomPriceId(Long stateroomPriceId) {
        this.stateroomPriceId = stateroomPriceId;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getLocationSide() {
        return locationSide;
    }

    public void setLocationSide(String locationSide) {
        this.locationSide = locationSide;
    }

    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    @Override
    public String toString() {
        return "StateroomDetailDTO{" +
                "stateroomId=" + stateroomId +
                ", type_name='" + type_name + '\'' +
                ", sizeSqft=" + sizeSqft +
                ", numBeds=" + numBeds +
                ", numBathrooms=" + numBathrooms +
                ", balcony=" + balcony +
                ", cruiseShipSide='" + cruiseShipSide + '\'' +
                ", stateroomPriceId=" + stateroomPriceId +
                ", tripId=" + tripId +
                ", locationSide='" + locationSide + '\'' +
                ", pricePerNight=" + pricePerNight +
                ", Num_Units=" + Num_Units +
                '}';
    }
}