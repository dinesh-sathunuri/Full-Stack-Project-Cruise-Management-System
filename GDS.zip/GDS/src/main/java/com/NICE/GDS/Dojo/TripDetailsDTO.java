package com.NICE.GDS.Dojo;

import java.util.List;

public class TripDetailsDTO {
    private Trip trip;
    private List<Restaurant> restaurants;
    private List<Entertainment> entertainments;

    public TripDetailsDTO(Trip trip, List<Restaurant> restaurants, List<Entertainment> entertainments) {
        this.trip = trip;
        this.restaurants = restaurants;
        this.entertainments = entertainments;
    }

    public Trip getTrip() {
        return trip;
    }

    public void setTrip(Trip trip) {
        this.trip = trip;
    }

    public List<Restaurant> getRestaurants() {
        return restaurants;
    }

    public void setRestaurants(List<Restaurant> restaurants) {
        this.restaurants = restaurants;
    }

    public List<Entertainment> getEntertainments() {
        return entertainments;
    }

    public void setEntertainments(List<Entertainment> entertainments) {
        this.entertainments = entertainments;
    }
}