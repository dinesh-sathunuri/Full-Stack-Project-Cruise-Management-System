package com.NICE.GDS.Services;

import com.NICE.GDS.Dojo.Group;
import com.NICE.GDS.Jdbc.PassengerJdbc;
import com.NICE.GDS.Dojo.OtpDetails;
import com.NICE.GDS.Dojo.Passenger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class PassengerService {

    private static final Logger logger = LoggerFactory.getLogger(PassengerService.class);
    private static final int OTP_EXPIRATION_SECONDS = 600; // 10 minutes

    @Autowired
    private PassengerJdbc passengerJdbc;

    @Autowired
    private JavaMailSender emailSender;

    // Temporary storage for OTPs by email
    private final Map<String, OtpDetails> otpStorage = new HashMap<>();

    public String sendOtp(String email) {
        String otp = generateOtp();
        storeOtp(email, otp);
        sendOtpEmail(email, otp);
        return "OTP sent to your email!";
    }

    private String generateOtp() {
        return String.format("%06d", new Random().nextInt(1000000));
    }

    public String sendOtpRegister(String email) {
        if (passengerJdbc.isEmailRegistered(email)) {
            return "Email is already registered.";
        }
        try {
            return sendOtp(email);
        } catch (Exception e) {
            logger.error("Error sending OTP: {}", e.getMessage());
            return "Failed to send OTP. Please try again later.";
        }
    }
    private void sendOtpEmail(String email, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP code is: " + otp);
        try {
            emailSender.send(message);
            logger.info("OTP sent to email: {}", email);
        } catch (MailException e) {
            logger.error("Failed to send OTP email to {}: {}", email, e.getMessage());
            throw new RuntimeException("Failed to send OTP. Please check your email address and try again.");
        }
    }

    public boolean validateOtpAndRegister(String email, String otp) {
        OtpDetails otpDetails = otpStorage.get(email);
        if (otpDetails != null && isOtpValid(otpDetails, otp)) {
            otpStorage.remove(email); // Clear OTP after successful validation
            return true;
        }
        return false;
    }

    private boolean isOtpValid(OtpDetails otpDetails, String otp) {
        return otpDetails.getOtp().equals(otp) && !isOtpExpired(otpDetails.getTimestamp());
    }

    private boolean isOtpExpired(Instant generatedTime) {
        return Instant.now().isAfter(generatedTime.plusSeconds(OTP_EXPIRATION_SECONDS));
    }

    // New method for checking if the email is registered
    public boolean isEmailRegistered(String email) {
        return passengerJdbc.isEmailRegistered(email);
    }
    public String registerPassenger(Passenger passenger) {
        // Assuming the email field is already included in Passenger object
        boolean isRegistered = passengerJdbc.insertPassenger(passenger);
        if (isRegistered) {
            return "Registration successful! You can log in now.";
        }
        return "Failed to register passenger. Please try again.";
    }

    private void storeOtp(String email, String otp) {
        otpStorage.put(email, new OtpDetails(otp, Instant.now()));
    }
    public void createGroup(Group group) {
        // Here, you can check if the group name is valid, log it, etc.
        // For this example, we directly proceed to save each passenger

        for (Passenger passenger : group.getPassengers()) {
            // Validate passenger details if necessary before inserting
            boolean isRegistered = passengerJdbc.insertPassenger(passenger);
            if (!isRegistered) {
                throw new RuntimeException("Failed to register passenger: " + passenger.getEmail());
            }
        }
        // Optionally, save group-related info if you have a group table
        // Example: groupJdbc.insertGroup(group);
    }
    public Passenger getPassengerByEmail(String email) {
        return passengerJdbc.findPassengerByEmail(email);
    }

    public void updatePassenger(Passenger passenger) {
        passengerJdbc.updatePassenger(passenger);
    }
}