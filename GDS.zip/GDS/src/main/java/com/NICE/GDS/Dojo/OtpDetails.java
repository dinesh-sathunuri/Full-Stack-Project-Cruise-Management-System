package com.NICE.GDS.Dojo;

import java.time.Instant;

public class OtpDetails {
    private final String otp;
    private final Instant timestamp;

    public OtpDetails(String otp, Instant timestamp) {
        this.otp = otp;
        this.timestamp = timestamp;
    }

    public String getOtp() {
        return otp;
    }

    public Instant getTimestamp() {
        return timestamp;
    }
}
