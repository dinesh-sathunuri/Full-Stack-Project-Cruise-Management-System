package com.NICE.GDS.Dojo;


import jakarta.persistence.*;

@Entity
public class Entertainment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "entertainment_id")
    private Long entertainmentId;

    @Column(name = "et_type", nullable = false)
    private String etType;

    @Column(name = "num_units", nullable = false)
    private Integer numUnits;

    @Column(name = "et_floor", nullable = false)
    private Integer etFloor;

    @Column(name = "age_restriction", nullable = false)
    private Integer ageRestriction;

    // Getters and Setters

    public Long getEntertainmentId() {
        return entertainmentId;
    }

    public void setEntertainmentId(Long entertainmentId) {
        this.entertainmentId = entertainmentId;
    }

    public String getEtType() {
        return etType;
    }

    public void setEtType(String etType) {
        this.etType = etType;
    }

    public Integer getNumUnits() {
        return numUnits;
    }

    public void setNumUnits(Integer numUnits) {
        this.numUnits = numUnits;
    }

    public Integer getEtFloor() {
        return etFloor;
    }

    public void setEtFloor(Integer etFloor) {
        this.etFloor = etFloor;
    }

    public Integer getAgeRestriction() {
        return ageRestriction;
    }

    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    public Entertainment(Long entertainmentId, String etType, Integer numUnits, Integer etFloor, Integer ageRestriction) {
        this.entertainmentId = entertainmentId;
        this.etType = etType;
        this.numUnits = numUnits;
        this.etFloor = etFloor;
        this.ageRestriction = ageRestriction;
    }

    public Entertainment() {
    }
}