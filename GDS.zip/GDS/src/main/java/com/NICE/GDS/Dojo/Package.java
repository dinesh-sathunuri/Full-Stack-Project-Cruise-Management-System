package com.NICE.GDS.Dojo;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
public class Package {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long packageId;

    @Column(name = "pk_type")
    private String pkType;

    private BigDecimal price;

    @Column(name = "age_restriction")
    private Integer ageRestriction;

    private Integer Quantity;

    public Integer getQuantity() {
        return Quantity;
    }

    public void setQuantity(Integer quantity) {
        Quantity = quantity;
    }

    private String duration;

    public Long getPackageId() {
        return packageId;
    }

    public void setPackageId(Long packageId) {
        this.packageId = packageId;
    }

    public String getPkType() {
        return pkType;
    }

    public void setPkType(String pkType) {
        this.pkType = pkType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getAgeRestriction(int age_restriction) {
        return ageRestriction;
    }

    public void setAgeRestriction(Integer ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    public String getDuration() {
        return duration;
    }

    @Override
    public String toString() {
        return "Package{" +
                "packageId=" + packageId +
                ", pkType='" + pkType + '\'' +
                ", price=" + price +
                ", ageRestriction=" + ageRestriction +
                ", Quantity=" + Quantity +
                ", duration='" + duration + '\'' +
                '}';
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}