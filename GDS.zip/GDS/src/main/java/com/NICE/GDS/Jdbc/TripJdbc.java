package com.NICE.GDS.Jdbc;

import com.NICE.GDS.Dojo.*;
import com.NICE.GDS.Dojo.Package;
import org.springframework.aop.config.PointcutEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TripJdbc {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private RowMapper<StateroomDetailDTO> rowMapper_SR = new RowMapper<StateroomDetailDTO>() {
        @Override
        public StateroomDetailDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
            StateroomDetailDTO detailDTO = new StateroomDetailDTO();

            // Mapping values from the gds_stateroom table
            detailDTO.setStateroomId(rs.getLong("gs.stateroom_id"));
            detailDTO.setType_name(rs.getString("type"));
            detailDTO.setSizeSqft(rs.getInt("gs.size_sqft"));
            detailDTO.setNumBeds(rs.getInt("gs.num_beds"));
            detailDTO.setNumBathrooms(rs.getInt("gs.num_bathrooms"));
            detailDTO.setBalcony(rs.getInt("gs.balcony"));
            detailDTO.setCruiseShipSide(rs.getString("gs.cruise_ship_side"));

            // Mapping values from the gds_stateroom_price table
            detailDTO.setStateroomPriceId(rs.getLong("gsp.stateroom_price_id"));
            detailDTO.setTripId(rs.getLong("gsp.trip_id"));
            detailDTO.setLocationSide(rs.getString("gsp.location_side"));
            detailDTO.setPricePerNight(rs.getBigDecimal("gsp.price_per_night"));
            detailDTO.setNum_Units(rs.getInt("gsp.num_units"));

            return detailDTO;
        }
    };


    public List<StateroomDetailDTO> findDetailsByTripId(Long tripId) {
        String sql = """
                    SELECT
                    gs.stateroom_id,
                    gst.stateroom_type AS type,
                    gs.size_sqft,
                    gs.num_beds,
                    gs.num_bathrooms,
                    gs.balcony,
                    gs.cruise_ship_side,
                    gsp.stateroom_price_id,
                    gsp.trip_id,
                    gsp.location_side,
                    gsp.price_per_night,
                    gsp.num_units
                FROM
                    gds_stateroom gs
                JOIN
                    gds_stateroom_type gst
                    ON gs.type_id = gst.type_id  -- Join the type table on type_id
                JOIN
                    gds_stateroom_price gsp
                    ON gs.stateroom_id = gsp.stateroom_id
                WHERE
                    gsp.trip_id = ? FOR UPDATE WAIT 5
                        """;
        return jdbcTemplate.query(sql, rowMapper_SR, tripId);
    }


    public List<Package> findAllPackages() {
        String sql = "SELECT * FROM gds_package";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Package pkg = new Package();
            pkg.setPackageId(rs.getLong("package_id"));
            pkg.setPkType(rs.getString("pk_type"));

            // Add logging to inspect the price value
            String priceString = rs.getString("price");
            System.out.println("Package Price: " + priceString); // Logging the price string

            try {
                pkg.setPrice(rs.getBigDecimal("price"));
            } catch (NumberFormatException e) {
                System.err.println("Error parsing price: " + e.getMessage());
                // Handle the error appropriately, maybe default to zero
                pkg.setPrice(BigDecimal.ZERO);
            }

            pkg.setDuration(rs.getString("duration"));
            pkg.getAgeRestriction(rs.getInt("age_restriction"));
            System.out.println(pkg);
            return pkg;
        });
    }

    public List<Trip> getAllTrips() {
        String sql = """
                    SELECT t.trip_id, p1.port_name AS start_port, p2.port_name AS end_port,
                           t.num_nights, t.start_date, t.end_date
                    FROM gds_trip t
                    JOIN gds_port p1 ON t.start_port = p1.port_id
                    JOIN gds_port p2 ON t.end_port = p2.port_id
                    WHERE t.start_date = CURRENT_DATE

                    UNION

                    SELECT t.trip_id, p1.port_name AS start_port, p2.port_name AS end_port,
                           t.num_nights, t.start_date, t.end_date
                    FROM gds_trip t
                    JOIN gds_port p1 ON t.start_port = p1.port_id
                    JOIN gds_port p2 ON t.end_port = p2.port_id
                    WHERE t.start_date BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 7 MONTH)
                """;

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Trip trip = new Trip();
            trip.setTripId(rs.getInt("trip_id"));
            trip.setStartPort(rs.getString("start_port"));
            trip.setEndPort(rs.getString("end_port"));
            trip.setNumNights(rs.getInt("num_nights"));
            trip.setStartDate(rs.getDate("start_date").toLocalDate());
            trip.setEndDate(rs.getDate("end_date").toLocalDate());
            return trip;
        });
    }

    public Trip getTripById(int tripId) {
        String sql = """
                SELECT t.trip_id, p1.port_name AS start_port, p2.port_name AS end_port,
                       t.num_nights, t.start_date, t.end_date
                FROM gds_trip t
                JOIN gds_port p1 ON t.start_port = p1.port_id
                JOIN gds_port p2 ON t.end_port = p2.port_id
                WHERE t.trip_id = ? FOR UPDATE WAIT 5
                """;
        return jdbcTemplate.queryForObject(sql, new Object[]{tripId}, (rs, rowNum) -> {
            Trip trip = new Trip();
            trip.setTripId(rs.getInt("trip_id"));
            trip.setStartPort(rs.getString("start_port"));
            trip.setEndPort(rs.getString("end_port"));
            trip.setNumNights(rs.getInt("num_nights"));
            trip.setStartDate(rs.getDate("start_date").toLocalDate());  // Use getDate for Date columns
            trip.setEndDate(rs.getDate("end_date").toLocalDate());      // Use getDate for Date columns
            return trip;
        });
    }

    public List<Restaurant> getRestaurantsByTripId(int tripId) {
        String sql = """
                SELECT
                    r.restaurant_id,
                    r.rt_name,
                    r.rt_type,
                    r.rt_floor,
                    r.opening_time,
                    r.closing_time
                FROM
                    gds_restaurant r
                WHERE
                    EXISTS (
                        SELECT 1
                        FROM gds_restaurant_schedule rs
                        WHERE rs.restaurant_id = r.restaurant_id
                        AND rs.trip_id = ? FOR UPDATE WAIT 5
                    );
                """;

        return jdbcTemplate.query(sql, new Object[]{tripId}, (rs, rowNum) -> {
            Restaurant restaurant = new Restaurant();
            restaurant.setRestaurantId((long) rs.getInt("restaurant_id"));
            restaurant.setRtName(rs.getString("rt_name"));
            restaurant.setRtType(rs.getString("rt_type"));
            restaurant.setRtFloor(rs.getInt("rt_floor"));
            restaurant.setOpeningTime(Timestamp.valueOf(rs.getTimestamp("opening_time").toLocalDateTime()));
            restaurant.setClosingTime(Timestamp.valueOf(rs.getTimestamp("closing_time").toLocalDateTime()));
            return restaurant;
        });
    }

    public List<Entertainment> getEntertainmentByTripId(int tripId) {
        String sql = """
                SELECT
                    e.entertainment_id,
                    e.et_type,
                    e.num_units,
                    e.et_floor,
                    e.age_restriction
                FROM
                    gds_entertainment e
                WHERE
                    EXISTS (
                        SELECT 1
                        FROM gds_trip_entertainment te
                        WHERE te.entertainment_id = e.entertainment_id
                        AND te.trip_id = ?
                    );
                """;

        return jdbcTemplate.query(sql, new Object[]{tripId}, (rs, rowNum) -> {
            Entertainment entertainment = new Entertainment();
            entertainment.setEntertainmentId((long) rs.getInt("entertainment_id"));
            entertainment.setEtType(rs.getString("et_type"));
            entertainment.setNumUnits(rs.getInt("num_units"));
            entertainment.setEtFloor(rs.getInt("et_floor"));
            entertainment.setAgeRestriction(rs.getInt("age_restriction"));
            return entertainment;
        });
    }

    public List<Package> getPackageById(int packageId) {
        String sql = "SELECT * FROM gds_package where package_id=?";
        return jdbcTemplate.query(sql, new Object[]{packageId}, (rs, rowNum) -> {
            Package pkg = new Package();
            pkg.setPackageId(rs.getLong("package_id"));
            pkg.setPkType(rs.getString("pk_type"));

            // Add logging to inspect the price value
            String priceString = rs.getString("price");
            System.out.println("Package Price: " + priceString); // Logging the price string

            try {
                pkg.setPrice(rs.getBigDecimal("price"));
            } catch (NumberFormatException e) {
                System.err.println("Error parsing price: " + e.getMessage());
                // Handle the error appropriately, maybe default to zero
                pkg.setPrice(BigDecimal.ZERO);
            }

            pkg.setDuration(rs.getString("duration"));
            pkg.getAgeRestriction(rs.getInt("age_restriction"));
            System.out.println(pkg);
            return pkg;
        });
    }

    public List<StateroomDetailDTO> getStateroomDetailById(int stateroomPriceId) {
        String sql = """
                SELECT 
                    gs.stateroom_id, 
                    gst.stateroom_type AS type, 
                    gs.size_sqft, 
                    gs.num_beds, 
                    gs.num_bathrooms, 
                    gs.balcony, 
                    gs.cruise_ship_side, 
                    gsp.stateroom_price_id, 
                    gsp.location_side, 
                    gsp.price_per_night,
                    gsp.num_units 
                FROM 
                    gds_stateroom gs
                JOIN 
                    gds_stateroom_type gst 
                    ON gs.type_id = gst.type_id 
                JOIN 
                    gds_stateroom_price gsp 
                    ON gs.stateroom_id = gsp.stateroom_id
                WHERE 
                    gsp.stateroom_price_id = ? 
                    AND EXISTS (
                        SELECT 1
                        FROM gds_stateroom_price gsp2
                        WHERE gsp2.stateroom_id = gs.stateroom_id
                        AND gsp2.stateroom_price_id = gsp.stateroom_price_id
                    )
                """;

        return jdbcTemplate.query(sql, new Object[]{stateroomPriceId}, (rs, rowNum) -> {
            StateroomDetailDTO detailDTO = new StateroomDetailDTO();
            detailDTO.setStateroomId(rs.getLong("gs.stateroom_id"));
            detailDTO.setType_name(rs.getString("type"));
            detailDTO.setSizeSqft(rs.getInt("gs.size_sqft"));
            detailDTO.setNumBeds(rs.getInt("gs.num_beds"));
            detailDTO.setNumBathrooms(rs.getInt("gs.num_bathrooms"));
            detailDTO.setBalcony(rs.getInt("gs.balcony"));
            detailDTO.setCruiseShipSide(rs.getString("gs.cruise_ship_side"));

            detailDTO.setStateroomPriceId(rs.getLong("gsp.stateroom_price_id"));
            detailDTO.setLocationSide(rs.getString("gsp.location_side"));
            detailDTO.setPricePerNight(rs.getBigDecimal("gsp.price_per_night"));
            detailDTO.setNum_Units(rs.getInt("gsp.num_units"));

            return detailDTO;
        });
    }

    public List<Group> getGroupsByEmail(String email) {
        String query = "SELECT g.group_id, g.group_name, g.num_members, " +
                "p.passenger_id, p.first_name, p.last_name, p.email " +
                "FROM gds_group g " +
                "JOIN gds_passenger_group pg ON g.group_id = pg.group_id " +
                "JOIN gds_passenger p ON pg.passenger_id = p.passenger_id " +
                "WHERE p.passenger_id IN (" +
                "   SELECT pg.passenger_id " +
                "   FROM gds_passenger p2 " +
                "   JOIN gds_passenger_group pg ON p2.passenger_id = pg.passenger_id " +
                "   WHERE p2.email = ? " +
                ");";

        // Create a Map to hold Groups and their corresponding passengers
        Map<Long, Group> groupMap = new HashMap<>();
        System.out.println("Fetching groups for email: " + email);

        jdbcTemplate.query(query, new Object[]{email}, rs -> {
            long groupId = rs.getLong("group_id");
            String groupName = rs.getString("group_name");
            int numMembers = rs.getInt("num_members");

            // Check if the group already exists in the map
            Group group = groupMap.get(groupId);
            if (group == null) {
                // Create a new group if it doesn't exist
                group = new Group();
                group.setGroupId(groupId);
                group.setGroupName(groupName);
                group.setGroupNum(numMembers);
                group.setPassengers(new ArrayList<>());  // Initialize passengers list
                groupMap.put(groupId, group);
            }

            // Create and add a passenger to this group
            Passenger passenger = new Passenger();
            passenger.setpassenger_Id(rs.getLong("passenger_id")); // Adjusted method name
            passenger.setFirstName(rs.getString("first_name"));
            passenger.setLastName(rs.getString("last_name"));
            passenger.setEmail(rs.getString("email"));

            group.getPassengers().add(passenger); // Add passenger to the group's list
        });

        // Return the list of groups with their passengers
        return new ArrayList<>(groupMap.values());
    }

    public List<Port> findAllPort() {
        String sql = """
                Select * from gds_port;
                """;

        return jdbcTemplate.query(sql, new Object[]{}, (rs, rowNum) -> {
            Port port = new Port();
            port.setId(rs.getLong("port_id"));
            port.setPortName(rs.getString("port_name"));
            port.setStreetAddress(rs.getString("port_street_address"));
            port.setCity(rs.getString("port_city"));
            port.setState(rs.getString("port_state"));
            port.setZipCode(rs.getString("port_zip_code"));
            port.setCountry(rs.getString("country"));
            port.setNearestAirport(rs.getString("nearest_airport"));
            port.setParkingSpots(rs.getInt("parking_spots"));
            return port;
        });
    }

    public void InsertTrip(Trip tripRequest, int StartPort, int EndPort) {
        String sql = """
                INSERT INTO gds_trip (start_port, end_port, num_nights, start_date, end_date)
                VALUES (?, ?, ?, ?, ?) 
                """;

        jdbcTemplate.update(sql,
                StartPort,
                EndPort,
                tripRequest.getNumNights(),
                tripRequest.getStartDate(),
                tripRequest.getEndDate()
        );
    }

    public int getPortByName(String portName) {
        String sql = """
                SELECT port_id FROM gds_port WHERE port_name = ?
                """;

        try {
            // Executes the query and maps the result to an integer (port_id)
            return jdbcTemplate.queryForObject(sql, new Object[]{portName}, Integer.class);
        } catch (EmptyResultDataAccessException e) {
            // Handle case where no result is found
            throw new RuntimeException("Port not found: " + portName);
        }
    }

    public void InsertRestaurant(Restaurant restaurant) {
        // SQL query to insert the restaurant data
        String sql = "INSERT INTO gds_restaurant (rt_name, rt_type, rt_floor, opening_time, closing_time, serves_breakfast, serves_lunch, serves_dinner) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ";

        // Execute the insert query using JdbcTemplate
        jdbcTemplate.update(sql,
                restaurant.getRtName(),
                restaurant.getRtType(),
                restaurant.getRtFloor(),
                restaurant.getOpeningTime(),
                restaurant.getClosingTime(),
                restaurant.getServesBreakfast(),
                restaurant.getServesLunch(),
                restaurant.getServesDinner());
    }

    public void InsertEntertainment(Entertainment entertainment) {
        // SQL query to insert the entertainment data
        String sql = "INSERT INTO gds_entertainment (et_type, num_units, et_floor, age_restriction) "
                + "VALUES (?, ?, ?, ?) ";

        // Execute the insert query using JdbcTemplate
        jdbcTemplate.update(sql,
                entertainment.getEtType(),
                entertainment.getNumUnits(),
                entertainment.getEtFloor(),
                entertainment.getAgeRestriction());
    }

    public List<Entertainment> getEntertainment() {
        String sql = """
                SELECT e.entertainment_id, e.et_type, e.num_units,
                       e.et_floor, e.age_restriction
                FROM gds_entertainment e
                """;

        return jdbcTemplate.query(sql, new Object[]{}, (rs, rowNum) -> {
            Entertainment entertainment = new Entertainment();
            entertainment.setEntertainmentId((long) rs.getInt("entertainment_id"));
            entertainment.setEtType(rs.getString("et_type"));
            entertainment.setNumUnits(rs.getInt("num_units"));
            entertainment.setEtFloor(rs.getInt("et_floor"));
            entertainment.setAgeRestriction(rs.getInt("age_restriction"));
            return entertainment;
        });
    }

    public List<Restaurant> getRestaurants() {
        String sql = """
                SELECT r.restaurant_id, r.rt_name, r.rt_type, r.rt_floor,
                       r.opening_time, r.closing_time
                FROM gds_restaurant r 
                """;

        return jdbcTemplate.query(sql, new Object[]{}, (rs, rowNum) -> {
            Restaurant restaurant = new Restaurant();
            restaurant.setRestaurantId((long) rs.getInt("restaurant_id"));
            restaurant.setRtName(rs.getString("rt_name"));
            restaurant.setRtType(rs.getString("rt_type"));
            restaurant.setRtFloor(rs.getInt("rt_floor"));
            restaurant.setOpeningTime(Timestamp.valueOf(rs.getTimestamp("opening_time").toLocalDateTime()));
            restaurant.setClosingTime(Timestamp.valueOf(rs.getTimestamp("closing_time").toLocalDateTime()));
            return restaurant;
        });

    }

    public List<RestaurantSchedule> getScheduledRestaurant(int tripId) {
        String sql = """
                SELECT rs.restaurant_schedule_id, rs.schedule_date, rs.meal_type, 
                       r.restaurant_id, r.rt_name, r.rt_type, r.rt_floor, 
                       r.opening_time, r.closing_time
                FROM gds_restaurant_schedule rs
                JOIN gds_restaurant r ON rs.restaurant_id = r.restaurant_id
                WHERE rs.trip_id = ? 
                """;

        return jdbcTemplate.query(sql, new Object[]{tripId}, (rs, rowNum) -> {
            // Mapping RestaurantSchedule
            RestaurantSchedule schedule = new RestaurantSchedule();
            schedule.setRestaurantScheduleId((long) rs.getInt("restaurant_schedule_id"));
            schedule.setScheduleDate(rs.getDate("schedule_date"));
            schedule.setMealType(rs.getString("meal_type"));

            // Mapping Restaurant details
            Restaurant restaurant = new Restaurant();
            restaurant.setRestaurantId((long) rs.getInt("restaurant_id"));
            restaurant.setRtName(rs.getString("rt_name"));
            restaurant.setRtType(rs.getString("rt_type"));
            restaurant.setRtFloor(rs.getInt("rt_floor"));
            restaurant.setOpeningTime(Timestamp.valueOf(rs.getTimestamp("opening_time").toLocalDateTime()));
            restaurant.setClosingTime(Timestamp.valueOf(rs.getTimestamp("closing_time").toLocalDateTime()));

            schedule.setRestaurant(restaurant);
            return schedule;
        });
    }
    public List<TripEntertainment> getScheduledEntertainment(int tripId) {
        String sql = """
            SELECT te.trip_id, te.entertainment_id, te.schedule, 
                   e.et_type, e.num_units, e.et_floor, e.age_restriction
            FROM gds_trip_entertainment te
            JOIN gds_entertainment e ON te.entertainment_id = e.entertainment_id
            WHERE te.trip_id = ? 
            """;

        return jdbcTemplate.query(sql, new Object[]{tripId}, (rs, rowNum) -> {
            // Mapping TripEntertainment
            TripEntertainment tripEntertainment = new TripEntertainment();
            tripEntertainment.setTripId(rs.getInt("trip_id"));
            tripEntertainment.setSchedule(rs.getDate("schedule"));

            // Mapping Entertainment details
            Entertainment entertainment = new Entertainment();
            entertainment.setEntertainmentId((long) rs.getInt("entertainment_id"));
            entertainment.setEtType(rs.getString("et_type"));
            entertainment.setNumUnits(rs.getInt("num_units"));
            entertainment.setEtFloor(rs.getInt("et_floor"));
            entertainment.setAgeRestriction(rs.getInt("age_restriction"));

            tripEntertainment.setEntertainment(entertainment);
            return tripEntertainment;
        });
    }

    public void InsertTripRestaurant(RestaurantSchedule restaurantSchedule) {
        String sql = """
        INSERT INTO gds_restaurant_schedule (schedule_date, meal_type, trip_id, restaurant_id)
        VALUES (?, ?, ?, ?)
        """;

        jdbcTemplate.update(sql,
                restaurantSchedule.getScheduleDate(),
                restaurantSchedule.getMealType(),
                restaurantSchedule.getTripId(),
                restaurantSchedule.getRestaurantScheduleId()
        );
    }

    public void InsertTripEntertainment(TripEntertainment tripEntertainment) {
        String sql = """
        INSERT INTO gds_trip_entertainment (trip_id, entertainment_id, schedule)
        VALUES (?, ?, ?)
        """;

        jdbcTemplate.update(sql,
                tripEntertainment.getTripId(),
                tripEntertainment.getEntertainmentId(),
                tripEntertainment.getSchedule()
        );
    }

    public List<StateroomDetailDTO> GetStateRoomDetails() {
        String sql = """
        SELECT
            s.stateroom_id,
            s.size_sqft,
            s.num_beds,
            s.num_bathrooms,
            s.balcony,
            s.cruise_ship_side,
            st.stateroom_type
        FROM
            gds_stateroom s
        JOIN
            gds_stateroom_type st ON s.type_id = st.type_id
    """;

        // Query the database and map the result to a list of StateroomDetailDTO
        List<StateroomDetailDTO> stateroomDetails = jdbcTemplate.query(sql, (rs, rowNum) -> {
            StateroomDetailDTO stateroomDetail = new StateroomDetailDTO();
            stateroomDetail.setStateroomId((long) rs.getInt("stateroom_id"));
            stateroomDetail.setSizeSqft(rs.getInt("size_sqft"));
            stateroomDetail.setNumBeds(rs.getInt("num_beds"));
            stateroomDetail.setNumBathrooms(rs.getInt("num_bathrooms"));
            stateroomDetail.setBalcony(rs.getInt("balcony"));
            stateroomDetail.setCruiseShipSide(rs.getString("cruise_ship_side"));
            stateroomDetail.setType_name(rs.getString("stateroom_type"));
            return stateroomDetail;
        });

        return stateroomDetails;
    }

    public void insertStateroomprice(StateroomPrice stateroomPrice) {
        String sql = """
    INSERT INTO gds_stateroom_price (stateroom_id, trip_id, location_side, price_per_night, num_units)
    VALUES (?, ?, ?, ?, ?)
    """;

        jdbcTemplate.update(sql,
                stateroomPrice.getStateroomId(),
                stateroomPrice.getTripId(),
                stateroomPrice.getLocationSide(),
                stateroomPrice.getPricePerNight(),
                stateroomPrice.getNumUnits()
        );
    }
}