package com.NICE.GDS.Dojo;

import jakarta.persistence.*;

import java.time.LocalDate;

public class Trip {

    @Id
    private int tripId;

    @Column(name = "start_port")
    private String startPort;

    @Column(name = "end_port")
    private String endPort;

    private int numNights;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    // Default constructor
    public Trip() {
    }
    public int getTripId() {
        return tripId;
    }

    public void setTripId(int tripId) {
        this.tripId = tripId;
    }

    public String getStartPort() {
        return startPort;
    }

    public void setStartPort(String startPort) {
        this.startPort = startPort;
    }

    public String getEndPort() {
        return endPort;
    }

    public void setEndPort(String endPort) {
        this.endPort = endPort;
    }

    public int getNumNights() {
        return numNights;
    }

    public void setNumNights(int numNights) {
        this.numNights = numNights;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "Trip{" +
                "tripId=" + tripId +
                ", startPort='" + startPort + '\'' +
                ", endPort='" + endPort + '\'' +
                ", numNights=" + numNights +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Trip)) return false;
        Trip trip = (Trip) o;
        return tripId == trip.tripId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(tripId);
    }
}