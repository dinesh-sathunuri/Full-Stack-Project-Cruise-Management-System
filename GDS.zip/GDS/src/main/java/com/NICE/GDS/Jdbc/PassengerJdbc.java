package com.NICE.GDS.Jdbc;

import com.NICE.GDS.Dojo.Passenger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PassengerJdbc {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PassengerJdbc(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // Insert new passenger into the database
    public boolean insertPassenger(Passenger passenger) {
        String sql = "INSERT INTO gds_passenger (first_name, last_name, email, date_of_birth, street_address, city, state, zip_code, country, gender, nationality, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        return jdbcTemplate.update(sql,
                passenger.getFirstName(),
                passenger.getLastName(),
                passenger.getEmail(),
                passenger.getDateOfBirth(),
                passenger.getStreetAddress(),
                passenger.getCity(),
                passenger.getState(),
                passenger.getZipCode(),
                passenger.getCountry(),
                passenger.getGender(),
                passenger.getNationality(),
                passenger.getPhone()
        ) > 0;
    }

    // Check if the email is registered
    public boolean isEmailRegistered(String email) {
        String sql = "SELECT COUNT(*) FROM gds_passenger WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    public Passenger findPassengerByEmail(String email) {
        String sql = "SELECT * FROM gds_passenger WHERE email = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Passenger.class), email);
    }

    public void updatePassenger(Passenger passenger) {
        String sql = """
                    UPDATE gds_passenger 
                    SET 
                        first_name = ?, 
                        last_name = ?, 
                        date_of_birth = ?, 
                        street_address = ?, 
                        city = ?, 
                        state = ?, 
                        zip_code = ?, 
                        country = ?, 
                        gender = ?, 
                        nationality = ?, 
                        phone = ?
                    WHERE email = ?
                """;

        jdbcTemplate.update(sql,
                passenger.getFirstName(),
                passenger.getLastName(),
                passenger.getDateOfBirth(),
                passenger.getStreetAddress(),
                passenger.getCity(),
                passenger.getState(),
                passenger.getZipCode(),
                passenger.getCountry(),
                passenger.getGender(),
                passenger.getNationality(),
                passenger.getPhone(),
                passenger.getEmail()
        );
    }

    public Passenger findByEmail(String email) {
        String sql = "SELECT passenger_id FROM gds_passenger WHERE email = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Passenger.class), email);
    }

    public List<Passenger> getPassengersByIds(List<Integer> passengerIds) {
        List<Passenger> passengers = new ArrayList<>();

        if (passengerIds.isEmpty()) {
            return passengers;
        }
        return passengers;
    }
}