package com.NICE.GDS.Dojo;

import java.util.List;

public class BookingWithDetails {
    private Booking booking;
    private List<StateroomDetailDTO> stateroomDetails;
    private List<Package> purchasedPackages;

    private List<Passenger> passengers;

    // Constructor
    public BookingWithDetails(Booking booking, List<StateroomDetailDTO> stateroomDetails, List<Package> purchasedPackages,List<Passenger> passengers) {
        this.booking = booking;
        this.stateroomDetails = stateroomDetails;
        this.purchasedPackages = purchasedPackages;
        this.passengers=passengers;
    }

    public List<Passenger> getPassengers() {
        return passengers;
    }

    public void setPassengers(List<Passenger> passengers) {
        this.passengers = passengers;
    }

    // Getters and Setters
    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public List<StateroomDetailDTO> getStateroomDetails() {
        return stateroomDetails;
    }

    public void setStateroomDetails(List<StateroomDetailDTO> stateroomDetails) {
        this.stateroomDetails = stateroomDetails;
    }

    public List<Package> getPurchasedPackages() {
        return purchasedPackages;
    }

    public void setPurchasedPackages(List<Package> purchasedPackages) {
        this.purchasedPackages = purchasedPackages;
    }

    @Override
    public String toString() {
        return "BookingWithDetails{" +
                "booking=" + booking +
                ", stateroomDetails=" + stateroomDetails +
                ", purchasedPackages=" + purchasedPackages +
                '}';
    }
}
