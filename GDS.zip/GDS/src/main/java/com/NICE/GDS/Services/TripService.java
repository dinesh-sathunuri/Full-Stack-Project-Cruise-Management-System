package com.NICE.GDS.Services;

import com.NICE.GDS.Dojo.*;
import com.NICE.GDS.Dojo.Package;
import com.NICE.GDS.Jdbc.TripJdbc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TripService {
    @Autowired
    private TripJdbc tripJdbc;

    public List<Package> getPackages() {
        return tripJdbc.findAllPackages();
    }
    public List<StateroomDetailDTO> getStateroomDetailsByTripId(Long tripId) {
        return tripJdbc.findDetailsByTripId(tripId);
    }
    public TripDetailsDTO getTripDetails(int tripId) {
        Trip trip = tripJdbc.getTripById(tripId);
        List<Restaurant> restaurants = tripJdbc.getRestaurantsByTripId(tripId);
        List<Entertainment> entertainments = tripJdbc.getEntertainmentByTripId(tripId);
        return new TripDetailsDTO(trip, restaurants, entertainments);
    }

    public List<Trip> getAllTrips() {
        return tripJdbc.getAllTrips();
    }

    public Trip getTripById(int tripId) {
        return tripJdbc.getTripById(tripId);
    }

    public List<Package> getPackageDetails(int packageId) {
        return tripJdbc.getPackageById(packageId);
    }

    public List<StateroomDetailDTO> getStateroomDetailsById(int stateroomPriceId) {
        return tripJdbc.getStateroomDetailById(stateroomPriceId);
    }

    public List<Group> getGroupsByEmail(String email) {
        System.out.println(tripJdbc.getGroupsByEmail(email));
        return tripJdbc.getGroupsByEmail(email);
    }

    public List<Port> findAllPort() {
        return tripJdbc.findAllPort();
    }

    public ResponseEntity<String> createTrip(Trip tripRequest) {
        try {

            System.out.println(tripRequest);
            int StartId= tripJdbc.getPortByName(tripRequest.getStartPort());
            int EndId= tripJdbc.getPortByName(tripRequest.getEndPort());
            tripJdbc.InsertTrip(tripRequest,StartId,EndId);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Trip created successfully.");
        } catch (Exception e) {
            // Log the error for debugging purposes
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create trip: " + e.getMessage());
        }
    }

    public ResponseEntity<String> insertRestaurant(Restaurant restaurant) {
        try {
            tripJdbc.InsertRestaurant(restaurant);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("Restaurant added successfully");
        } catch (Exception e) {
            // Log the error for debugging purposes
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create Restaurant: " + e.getMessage());
        }
    }

    public ResponseEntity<String> insertEntrainment(Entertainment entertainment) {
        try {
            tripJdbc.InsertEntertainment(entertainment);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("entertainment added successfully");
        } catch (Exception e) {
            // Log the error for debugging purposes
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create entertainment: " + e.getMessage());
        }
    }

    public List<Entertainment> GetEntrainment() {
        return tripJdbc.getEntertainment();
    }

    public List<Restaurant> GetRestaurants() {
        return tripJdbc.getRestaurants();
    }

    public List<RestaurantSchedule> getScheduledRestuarant(int tripId) {
        return tripJdbc.getScheduledRestaurant(tripId);
    }

    public List<TripEntertainment> getScheduledEntertainment(int tripId) {
        return tripJdbc.getScheduledEntertainment(tripId);
    }

    public void InsertTripRestaurant(RestaurantSchedule restaurantSchedule) {
        tripJdbc.InsertTripRestaurant(restaurantSchedule);
    }

    public void InsertTripEntertainment(TripEntertainment tripEntertainment) {
        tripJdbc.InsertTripEntertainment(tripEntertainment);
    }

    public List<StateroomDetailDTO> GetStateRoomDetails() {
        return tripJdbc.GetStateRoomDetails();
    }

    public void insertStateroomprice(StateroomPrice stateroomPrice) {
        tripJdbc.insertStateroomprice(stateroomPrice);
    }
}
