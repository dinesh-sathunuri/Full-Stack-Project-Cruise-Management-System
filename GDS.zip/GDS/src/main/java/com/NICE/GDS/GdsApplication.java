package com.NICE.GDS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GdsApplication.class, args);
	}

}
