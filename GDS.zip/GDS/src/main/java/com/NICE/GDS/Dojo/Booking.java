package com.NICE.GDS.Dojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bookingId;

    // Change from single passengerId to a list of passengerIds
    @Column(name = "passenger_id")
    private List<Integer> passengerIds = new ArrayList<>();

    private Integer tripId;
    @JsonProperty("stateroom_price_id")
    private Integer stateroomId;

    @Column(name = "group_id", nullable = false)
    private Integer groupId;

    @Column(name = "booking_date", nullable = false)
    private LocalDate bookingDate;

    @Column(name = "total_price", nullable = false)
    private BigDecimal totalPrice; // Added totalPrice field

    @Column(name = "group_name")
    private String groupName;

    @Column(name = "num_members")
    private Integer numMembers;

    // No-argument constructor
    public Booking() {}

    // Getters and Setters
    public List<Integer> getPassengerIds() {
        return passengerIds;
    }

    public void setPassengerIds(List<Integer> passengerIds) {
        this.passengerIds = passengerIds;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public Integer getTripId() {
        return tripId;
    }

    public void setTripId(Integer tripId) {
        this.tripId = tripId;
    }

    public Integer getStateroomId() {
        return stateroomId;
    }

    public void setStateroomId(Integer stateroomId) {
        this.stateroomId = stateroomId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice; // Getter for totalPrice
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice; // Setter for totalPrice
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Integer getNumMembers() {
        return numMembers;
    }

    public void setNumMembers(Integer numMembers) {
        this.numMembers = numMembers;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "bookingId=" + bookingId +
                ", passengerIds=" + passengerIds +
                ", tripId=" + tripId +
                ", stateroomId=" + stateroomId +
                ", groupId=" + groupId +
                ", bookingDate=" + bookingDate +
                ", totalPrice=" + totalPrice + // Updated to totalPrice
                ", groupName='" + groupName + '\'' +
                ", numMembers=" + numMembers +
                '}';
    }

    // Override equals and hashCode if necessary
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Booking)) return false;
        Booking booking = (Booking) o;
        return bookingId.equals(booking.bookingId);
    }

    @Override
    public int hashCode() {
        return bookingId.hashCode();
    }

}