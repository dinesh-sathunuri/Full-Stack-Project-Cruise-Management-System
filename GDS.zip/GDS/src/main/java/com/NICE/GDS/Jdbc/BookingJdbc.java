package com.NICE.GDS.Jdbc;

import com.NICE.GDS.Dojo.*;
import com.NICE.GDS.Dojo.Package;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Repository
public class BookingJdbc {

    private static final Logger logger = Logger.getLogger(BookingJdbc.class.getName());

    private static JdbcTemplate jdbcTemplate = null;

    @Autowired
    public BookingJdbc(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public static List<Booking> getBookingDetailByEmail(String email) {
        String sql = """
                        SELECT
                                    gds_booking.booking_id,
                                    gds_booking.trip_id,
                                    gds_booking.stateroom_price_id,
                                    gds_booking.booking_date,
                                    gds_booking.total_cost,
                                    gds_group.group_id,
                                    gds_group.group_name,
                                    gds_group.num_members,
                                    gds_passenger.passenger_id,
                                    gds_passenger.first_name,
                                    gds_passenger.last_name,
                                    gds_passenger.email,
                                    gds_passenger.phone
                                FROM
                                    gds_booking
                                INNER JOIN
                                    gds_group ON gds_booking.group_id = gds_group.group_id
                                INNER JOIN
                                    gds_passenger_group ON gds_group.group_id = gds_passenger_group.group_id
                                INNER JOIN
                                    gds_passenger ON gds_passenger_group.passenger_id = gds_passenger.passenger_id
                                WHERE
                                    gds_group.group_id IN (
                                        SELECT gds_group.group_id
                                        FROM gds_passenger_group
                                        INNER JOIN gds_passenger ON gds_passenger_group.passenger_id = gds_passenger.passenger_id
                                        WHERE gds_passenger.email = ?
                                    )
                                ORDER BY gds_booking.booking_id;
                """;

        return jdbcTemplate.query(sql, new Object[]{email}, rs -> {
            List<Booking> bookings = new ArrayList<>();
            Map<Integer, Booking> bookingMap = new HashMap<>();

            while (rs.next()) {
                int bookingId = rs.getInt("booking_id");

                // Check if the booking is already added
                Booking booking = bookingMap.getOrDefault(bookingId, new Booking());
                if (!bookingMap.containsKey(bookingId)) {
                    booking.setBookingId(bookingId);
                    booking.setTripId(rs.getInt("trip_id"));
                    booking.setStateroomId(rs.getInt("stateroom_price_id"));
                    booking.setBookingDate(rs.getDate("booking_date").toLocalDate());
                    booking.setTotalPrice(rs.getBigDecimal("total_cost"));
                    booking.setGroupId(rs.getInt("group_id"));
                    booking.setGroupName(rs.getString("group_name"));
                    booking.setNumMembers(rs.getInt("num_members"));
                    bookingMap.put(bookingId, booking);
                }

                // Add group member details
                Passenger passenger = new Passenger();
                passenger.setpassenger_Id(rs.getLong("passenger_id"));
                passenger.setFirstName(rs.getString("first_name"));
                passenger.setLastName(rs.getString("last_name"));
                passenger.setEmail(rs.getString("email"));
                passenger.setPhone(rs.getString("phone"));
                booking.getPassengerIds().add((int) passenger.getpassenger_Id());
            }

            bookings.addAll(bookingMap.values());
            return bookings;
        });
    }

    public static List<BookingTrend> getBookingTrends() {
        String sql = "SELECT DATE(booking_date) as booking_date, COUNT(*) as booking_count FROM gds_booking GROUP BY booking_date ORDER BY booking_date";

        return jdbcTemplate.query(sql, rs -> {
            List<BookingTrend> trends = new ArrayList<>();
            while (rs.next()) {
                BookingTrend trend = new BookingTrend();
                trend.setDate(rs.getDate("booking_date").toLocalDate());
                trend.setBookingCount(rs.getInt("booking_count"));
                trends.add(trend);
            }
            return trends;
        });
    }


    public int insertGroup(String groupName, int numMembers) {
        try {
            String sql = "INSERT INTO gds_group (group_name, num_members) VALUES (?, ?)";
            jdbcTemplate.update(sql, groupName, numMembers);
            return jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        } catch (Exception e) {
            logger.severe("Error inserting group: " + e.getMessage());
            throw new RuntimeException("Failed to insert group", e);
        }
    }

    public int createBooking(Booking booking, int groupId) {
        try {
            String sql = "INSERT INTO gds_booking (trip_id, booking_date, total_cost, stateroom_price_id,group_id) VALUES (?, ?, ?, ?,?)";
            jdbcTemplate.update(sql,
                    booking.getTripId(),
                    Date.valueOf(LocalDate.now()), // Converts LocalDate to java.sql.Date
                    booking.getTotalPrice(),
                    booking.getStateroomId(),
                    groupId
            );
            return jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        } catch (Exception e) {
            logger.severe("Error creating booking: " + e.getMessage());
            throw new RuntimeException("Failed to create booking", e);
        }
    }

    public void insertPackagePurchase(int bookingId, long packageId, int quantity) {
        try {
            // Retrieve package price
            String priceSql = "SELECT price FROM gds_package WHERE package_id = ?";
            double packagePrice = jdbcTemplate.queryForObject(priceSql, new Object[]{packageId}, Double.class);
            double totalPrice = packagePrice * quantity;

            String sql = "INSERT INTO gds_package_purchase (booking_id, package_id, purchase_date, quantity, total_package_price) VALUES (?, ?, ?, ?, ?)";
            jdbcTemplate.update(sql, bookingId, packageId, LocalDate.now(), quantity, totalPrice);
        } catch (Exception e) {
            logger.severe("Error inserting package purchase: " + e.getMessage());
            throw new RuntimeException("Failed to insert package purchase", e);
        }
    }

    public boolean processPayment(int bookingId, int tripId, int groupId, String paymentMethod, BigDecimal totalPrice) {
        try {
            String sql = "INSERT INTO gds_payment (trip_id, group_id, payment_date, amount, payment_method, booking_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            return jdbcTemplate.update(sql,
                    tripId,
                    groupId,
                    LocalDate.now(),
                    totalPrice,
                    paymentMethod,
                    bookingId) > 0; // Ensure that an insert happened
        } catch (Exception e) {
            logger.severe("Error processing payment: " + e.getMessage());
            throw new RuntimeException("Failed to process payment", e);
        }
    }

    public void insertPassenger(int groupId, Integer passengerId) {
        try {
            String sql = "INSERT INTO gds_passenger_group (group_id, passenger_Id, join_date) VALUES (?, ?, ?)";
            jdbcTemplate.update(sql, groupId, passengerId,  Date.valueOf(LocalDate.now()));
        } catch (Exception e) {
            logger.severe("Error inserting passenger into group: " + e.getMessage());
            throw new RuntimeException("Failed to insert passenger into group", e);
        }
    }
    public List<Package> getPurchasePackages(int bookingId) {
        String sql = """
        SELECT 
            p.package_id, 
            p.pk_type, 
            p.price, 
            p.age_restriction, 
            p.duration, 
            pp.quantity
        FROM gds_package_purchase pp
        JOIN gds_package p ON pp.package_id = p.package_id
        WHERE pp.booking_id = ?
    """;

        try {
            return jdbcTemplate.query(sql, new Object[]{bookingId}, (rs, rowNum) -> {
                Package pkg = new Package();
                pkg.setPackageId(rs.getLong("package_id"));
                pkg.setPkType(rs.getString("pk_type"));
                pkg.setPrice(rs.getBigDecimal("price"));
                pkg.setAgeRestriction(rs.getInt("age_restriction"));
                pkg.setDuration(rs.getString("duration"));
                pkg.setQuantity(rs.getInt("quantity"));
                return pkg;
            });
        } catch (Exception e) {
            logger.severe(() -> "Error retrieving purchased packages: " + e.getMessage());
            throw new RuntimeException("Failed to retrieve purchased packages", e);
        }
    }

    public List<Map<String, Object>> getPackagePopularity() {
        String sql = """
    SELECT 
        p.pk_type AS packageType, 
        SUM(pp.quantity) AS numPurchases
    FROM gds_package_purchase pp
    JOIN gds_package p ON pp.package_id = p.package_id
    GROUP BY p.pk_type
    """;

        try {
            return jdbcTemplate.queryForList(sql);
        } catch (Exception e) {
            logger.severe(() -> "Error retrieving package popularity data: " + e.getMessage());
            throw new RuntimeException("Failed to retrieve package popularity", e);
        }
    }
}
