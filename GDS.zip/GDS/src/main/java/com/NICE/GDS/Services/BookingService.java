package com.NICE.GDS.Services;

import com.NICE.GDS.Dojo.*;
import com.NICE.GDS.Dojo.Package;
import com.NICE.GDS.Jdbc.BookingJdbc;
import com.NICE.GDS.Jdbc.PassengerJdbc;
import com.NICE.GDS.Jdbc.TripJdbc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BookingService {

    private final BookingJdbc bookingJdbc;

    private final TripJdbc tripJdbc;

    private final PassengerJdbc passengerJdbc;

    @Autowired
    public BookingService(BookingJdbc bookingJdbc, PassengerJdbc passengerJdbc, TripJdbc tripJdbc, PassengerJdbc passengerJdbc1) {
        this.bookingJdbc = bookingJdbc;
        this.tripJdbc = tripJdbc;
        this.passengerJdbc = passengerJdbc1;
    }
    @Transactional
    public com.NICE.GDS.Dojo.Booking createBookingWithTransaction(Booking booking, String paymentMethod, List<Package> pkgs) {
        // Step 1: Insert Group
        int groupId = bookingJdbc.insertGroup(booking.getGroupName(), booking.getNumMembers());

        // Step 2: Insert Booking
        int bookingId = bookingJdbc.createBooking(booking,groupId);

        // Step 3: Insert Package Purchases
        for (Package pkg : pkgs) {
            bookingJdbc.insertPackagePurchase(bookingId, pkg.getPackageId(), pkg.getQuantity());
        }

        // Step 4: Insert Passenger IDs
        for (Integer passengerId : booking.getPassengerIds()) {
            bookingJdbc.insertPassenger(groupId, passengerId);
        }

        // Step 5: Process Payment
        boolean paymentSuccess = bookingJdbc.processPayment(
                bookingId,
                booking.getTripId(),
                groupId,
                paymentMethod,
                booking.getTotalPrice()
        );

        if (!paymentSuccess) {
            throw new RuntimeException("Payment failed, transaction will be rolled back.");
        }

        // Set booking ID in Booking object and return
        booking.setBookingId(bookingId);
        return booking;
    }
    public List<BookingWithDetails> getPastBookingsByEmail(String email) {
        List<Booking> bookings = new ArrayList<>();
        bookings = BookingJdbc.getBookingDetailByEmail(email);
        List<BookingWithDetails> bookingWithDetailsList = new ArrayList<>();

        // Fetch stateroom details and packages for each booking
        for (Booking booking : bookings) {
            // Fetch stateroom details using the stateroomId from the booking
            List<StateroomDetailDTO> stateroomDetails = tripJdbc.getStateroomDetailById(booking.getStateroomId());

            // Fetch purchased packages for the booking
            List<Package> packages = bookingJdbc.getPurchasePackages(booking.getBookingId());

            List<Passenger> passengers = passengerJdbc.getPassengersByIds(booking.getPassengerIds());
            // Create a BookingWithDetails object and add it to the list
            BookingWithDetails bookingWithDetails = new BookingWithDetails(booking, stateroomDetails, packages,passengers);
            bookingWithDetailsList.add(bookingWithDetails);
        }
        System.out.println(bookingWithDetailsList);
        return bookingWithDetailsList;
    }

    public List<BookingTrend> getBookings() {
        return BookingJdbc.getBookingTrends();
    }

    public List<Map<String, Object>> getPackage() {
        return bookingJdbc.getPackagePopularity();
    }
}