package com.NICE.GDS.Dojo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.springframework.data.annotation.Id;

import java.sql.Timestamp;

public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "restaurant_id")
    private Long restaurantId;

    @Column(name = "rt_name", nullable = false)
    private String rtName;

    @Column(name = "rt_type", nullable = false)
    private String rtType;

    @Column(name = "rt_floor", nullable = false)
    private Integer rtFloor;

    @Column(name = "opening_time", nullable = false)
    private Timestamp openingTime;

    @Column(name = "closing_time", nullable = false)
    private Timestamp closingTime;

    @Column(name = "serves_breakfast", nullable = false)
    private Integer servesBreakfast;

    @Column(name = "serves_lunch", nullable = false)
    private Integer servesLunch;

    @Column(name = "serves_dinner", nullable = false)
    private Integer servesDinner;

    public Long getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Long restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getRtName() {
        return rtName;
    }

    public void setRtName(String rtName) {
        this.rtName = rtName;
    }

    public String getRtType() {
        return rtType;
    }

    public void setRtType(String rtType) {
        this.rtType = rtType;
    }

    public Integer getRtFloor() {
        return rtFloor;
    }

    public void setRtFloor(Integer rtFloor) {
        this.rtFloor = rtFloor;
    }

    public Timestamp getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(Timestamp openingTime) {
        this.openingTime = openingTime;
    }

    public Timestamp getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(Timestamp closingTime) {
        this.closingTime = closingTime;
    }

    public Integer getServesBreakfast() {
        return servesBreakfast;
    }

    public void setServesBreakfast(Integer servesBreakfast) {
        this.servesBreakfast = servesBreakfast;
    }

    public Integer getServesLunch() {
        return servesLunch;
    }

    public void setServesLunch(Integer servesLunch) {
        this.servesLunch = servesLunch;
    }

    public Integer getServesDinner() {
        return servesDinner;
    }

    public void setServesDinner(Integer servesDinner) {
        this.servesDinner = servesDinner;
    }
}