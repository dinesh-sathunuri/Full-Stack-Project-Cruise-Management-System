// src/components/PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';
import Cookies from 'js-cookie';

const PrivateRoute = ({ children }) => {
  const sessionId = Cookies.get('sessionId'); // Get the session from cookies
  return sessionId ? children : <Navigate to="/" />;
};

export default PrivateRoute;