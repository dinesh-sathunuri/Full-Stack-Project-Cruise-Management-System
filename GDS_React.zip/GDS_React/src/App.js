import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage'; 
import TripPage from './Pages/TripPage'; 
import TripList from './Pages/TripList'; 
import GroupCreation from './Pages/GroupCreation'; 
import PackageOverview from './Pages/PackageOverview';
import PrivateRoute from './Components/PrivateRoute'; 
import BookingPage from './Pages/BookingPage';
import NotFound from './Pages/NotFound'; 
import UserDetails from './Pages/UserDetails';
import PastBookings from './Pages/PastBookings';
import AdminTripList from './Pages/AdminTripList';
import InsertTrip from './Pages/InsertTrip';
import InsertRestaurant from './Pages/InsertRestaurant';
import InsertEntertainment from './Pages/InsertEntrainment';
import AdminTripDetails from './Pages/AdminTripDetails';
import AddRestaurantToTrip from './Pages/AddRestaurantToTrip';
import AddEntertainment from './Pages/AddEntertainment';
import InsertStateroomPrice from './Pages/InsertStateroomPrice';
import BookingTrendGraph from './Pages/BookingTrendGraph';
const App = () => {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route 
            path="/home" 
            element={
              <PrivateRoute>
                <TripList />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/adminhome" 
            element={
              <PrivateRoute>
                <AdminTripList />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/bookingtrend" 
            element={
              <PrivateRoute>
                <BookingTrendGraph />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/admintrip/:tripId" 
            element={
              <PrivateRoute>
                <AdminTripDetails />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/add-restaurant/:tripId" 
            element={
              <PrivateRoute>
                <AddRestaurantToTrip />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/stateroom/insert/:tripId" 
            element={
              <PrivateRoute>
                <InsertStateroomPrice />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/add-entertainment/:tripId" 
            element={
              <PrivateRoute>
                <AddEntertainment />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/trip/insert" 
            element={
              <PrivateRoute>
                <InsertTrip />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/restaurant/insert" 
            element={
              <PrivateRoute>
                <InsertRestaurant />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/entertainment/insert" 
            element={
              <PrivateRoute>
                <InsertEntertainment />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/trip/:tripId" 
            element={
              <PrivateRoute>
                <TripPage />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/create-group" 
            element={
              <PrivateRoute>
                <GroupCreation />
              </PrivateRoute>
            }
          />
          <Route 
            path="/packages" 
            element={
              <PrivateRoute>
                <PackageOverview />
              </PrivateRoute>
            }
          />
          <Route 
            path="/Booking" 
            element={
              <PrivateRoute>
                <BookingPage />
              </PrivateRoute>
            }
          />
          <Route 
            path="/profile" 
            element={
              <PrivateRoute>
                <UserDetails />
              </PrivateRoute>
            }
          />
          <Route 
            path="/recent-booking" 
            element={
              <PrivateRoute>
                <PastBookings />
              </PrivateRoute>
            }
          />
          {/* 404 Not Found Route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;