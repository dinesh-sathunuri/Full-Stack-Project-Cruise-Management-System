import React, { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import "jspdf-autotable";

const PastBookings = () => {
  const [pastBookings, setPastBookings] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Fetch past bookings for the logged-in user
  const fetchPastBookings = async () => {
    setError("");
    setLoading(true);
    const email = Cookies.get("sessionId");
  
    if (!email) {
      setError("No session found. Please log in.");
      setLoading(false);
      return;
    }
  
    try {
      const response = await axios.get("http://localhost:8080/api/bookings/past", {
        params: { email },
      });
  
      if (response.data && response.data.length > 0) {
        // Filter bookings to only include those that have the session email in the passengers' emails
        const filteredBookings = response.data.filter((booking) =>
          booking.passengers.some((passenger) => passenger.email === email)
        );
  
        if (filteredBookings.length > 0) {
          setPastBookings(filteredBookings);
        } else {
          setError("No past bookings found for the current session.");
        }
      } else {
        setError("No past bookings found.");
      }
      setLoading(false);
    } catch (err) {
      setError("An error occurred while fetching past bookings.");
      setLoading(false);
      console.error("Error fetching past bookings:", err);
    }
  };
  

  useEffect(() => {
    fetchPastBookings();
  }, []);

  // Render packages safely
  const renderPackages = (packages) => {
    if (!packages || packages.length === 0) return <p>No packages found.</p>;

    return (
      <ul>
        {packages.map((pkg, index) => (
          <li key={index}>
            {pkg.pkType} (Qty: {pkg.quantity}) - ${pkg.price} per person per night
          </li>
        ))}
      </ul>
    );
  };

  // Render passengers safely
  const renderPassengers = (passengers) => {
    if (!passengers || passengers.length === 0) return <p>No passengers found.</p>;

    return (
      <ul>
        {passengers.map((passenger, index) => (
          <li key={index}>
            <strong>{passenger.first_name} {passenger.last_name}</strong> - {passenger.email}
          </li>
        ))}
      </ul>
    );
  };

  // Render stateroom details safely
  const renderStateroomDetails = (staterooms) => {
    if (!staterooms || staterooms.length === 0) return <p>No stateroom details found.</p>;

    return (
      <ul>
        {staterooms.map((stateroom, index) => (
          <li key={index}>
            {stateroom.type_name} - {stateroom.sizeSqft} sqft, {stateroom.numBeds} beds, {stateroom.numBathrooms} bathroom(s)
          </li>
        ))}
      </ul>
    );
  };

  // Navigate back to home
  const handleBackButtonClick = () => {
    navigate("/home");
  };

  // Generate Booking Detail PDF
  const generateBookingDetailPDF = (booking) => {
    const doc = new jsPDF();
    doc.setFont("helvetica");

    // Title
    doc.setFontSize(20);
    doc.setTextColor(0, 0, 255); // Blue color for the title
    doc.text("Booking Details", 20, 20);

    // Booking Info
    doc.setTextColor(0, 0, 0); // Reset to black for body text
    doc.setFontSize(12);
    doc.text(`Booking ID: ${booking.booking.bookingId}`, 20, 40);
    doc.text(`Group Name: ${booking.booking.groupName}`, 20, 50);
    doc.text(`Booking Date: ${booking.booking.bookingDate}`, 20, 60);
    doc.text(`Total Price: $${booking.booking.totalPrice}`, 20, 70);

    // Packages Table
    doc.setFontSize(14);
    doc.text("Packages Purchased:", 20, 80);
    doc.setFontSize(12);
    doc.autoTable({
      startY: 85,
      head: [["Package Type", "Quantity", "Price per Night"]],
      body: booking.purchasedPackages.map((pkg) => [
        pkg.pkType,
        pkg.quantity,
        `$${pkg.price}`,
      ]),
      theme: "grid",
      styles: { fontSize: 10 },
    });

    // Passengers
    doc.setFontSize(14);
    doc.text("Passengers:", 20, doc.autoTable.previous.finalY + 10);
    doc.setFontSize(12);
    doc.autoTable({
      startY: doc.autoTable.previous.finalY + 15,
      head: [["First Name", "Last Name", "Email"]],
      body: booking.passengers.map((passenger) => [
        passenger.first_name,
        passenger.last_name,
        passenger.email,
      ]),
      theme: "grid",
      styles: { fontSize: 10 },
    });

    // Stateroom Details
    doc.setFontSize(14);
    doc.text("Stateroom Details:", 20, doc.autoTable.previous.finalY + 10);
    doc.setFontSize(12);
    doc.autoTable({
      startY: doc.autoTable.previous.finalY + 15,
      head: [["Type", "Size", "Beds", "Bathrooms"]],
      body: booking.stateroomDetails.map((stateroom) => [
        stateroom.type_name,
        `${stateroom.sizeSqft} sqft`,
        stateroom.numBeds,
        stateroom.numBathrooms,
      ]),
      theme: "grid",
      styles: { fontSize: 10 },
    });

    // Save the PDF
    doc.save(`Booking_Detail_${booking.booking.bookingId}.pdf`);
  };

  // Generate Invoice PDF
  // const generateInvoicePDF = (booking) => {
  //   const doc = new jsPDF();
  //   doc.setFont("helvetica");

  //   // Title
  //   doc.setFontSize(20);
  //   doc.setTextColor(0, 0, 255); // Blue color for the title
  //   doc.text("Invoice", 20, 20);

  //   // Invoice Info
  //   doc.setTextColor(0, 0, 0); // Reset to black for body text
  //   doc.setFontSize(12);
  //   doc.text(`Invoice Date: ${booking.booking.bookingDate}`, 20, 40);
  //   doc.text(`Booking ID: ${booking.booking.bookingId}`, 20, 50);
  //   doc.text(`Group Name: ${booking.booking.groupName}`, 20, 60);
  //   doc.text(`Total Price: $${booking.booking.totalPrice}`, 20, 70);

  //   // NICE address
  //   doc.setFontSize(12);
  //   doc.text("NICE", 20, 80);  // Title for the address
  //   doc.setFontSize(10);
  //   doc.text("6 MetroTech Center", 20, 90);
  //   doc.text("Brooklyn, NY 11201", 20, 100);

  //   // First Passenger's Address
  //   const firstPassenger = booking.passengers[0];
  //   doc.setFontSize(14);
  //   doc.text("Passenger's Address:", 20, 110);
  //   doc.setFontSize(12);
  //   doc.text(firstPassenger.street_address, 20, 120);
  //   doc.text(`${firstPassenger.city}, ${firstPassenger.state} ${firstPassenger.zip_code}`, 20, 130);
  //   doc.text(firstPassenger.country, 20, 140);

  //   // Packages Table
  //   doc.setFontSize(14);
  //   doc.text("Packages Purchased:", 20, 150);
  //   doc.setFontSize(12);
  //   doc.autoTable({
  //     startY: 155,
  //     head: [["Package Type", "Quantity", "Price per Night"]],
  //     body: booking.purchasedPackages.map((pkg) => [
  //       pkg.pkType,
  //       pkg.quantity,
  //       `$${pkg.price}`,
  //     ]),
  //     theme: "grid",
  //     styles: { fontSize: 10 },
  //   });

  //   // Save the PDF
  //   doc.save(`Invoice_${booking.booking.bookingId}.pdf`);
  // };

  return (
    <div style={styles.container}>
      <h1>Past Bookings</h1>
      <button onClick={handleBackButtonClick} style={styles.backButton}>Go to Home</button>
      {loading && <p>Loading past bookings...</p>}
      {error && <p style={styles.error}>{error}</p>}
      {pastBookings.length > 0 ? (
        <div style={styles.bookingsList}>
          {pastBookings.map((booking) => (
            <div key={booking.booking.bookingId}>
              <h3>Booking ID: {booking.booking.bookingId}</h3>
              <button onClick={() => generateBookingDetailPDF(booking)}>Download Booking Details PDF</button>
              {renderPackages(booking.purchasedPackages)}
              {renderPassengers(booking.passengers)}
              {renderStateroomDetails(booking.stateroomDetails)}
            </div>
          ))}
        </div>
      ) : (
        !loading && <p>No past bookings found.</p>
      )}
    </div>
  );
};

// Inline styles
const styles = {
  container: {
    maxWidth: "800px",
    margin: "0 auto",
    padding: "20px",
    backgroundColor: "#f9f9f9",
    borderRadius: "8px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  error: {
    color: "red",
    textAlign: "center",
  },
  bookingsList: {
    marginTop: "20px",
  },
  backButton: {
    backgroundColor: "#007bff",
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginBottom: "20px",
  },
};

export default PastBookings;
