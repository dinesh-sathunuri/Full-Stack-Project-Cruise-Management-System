import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { FaSignOutAlt, FaInfoCircle, FaShip, FaUserCircle, FaUtensils, FaTheaterMasks } from 'react-icons/fa';
import BookingTrendGraph from './BookingTrendGraph';

const Container = styled.div`
  display: flex;
  min-height: 100vh;
  font-family: 'Roboto', sans-serif;
`;

const Sidebar = styled.div`
  width: 225px;
  background: linear-gradient(180deg, #007bff, #0056b3);
  padding: 20px;
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  height: 100%;
  top: 0;
  left: 0;
  box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
`;

const SidebarTitle = styled.h2`
  font-size: 26px;
  font-weight: 700;
  margin-bottom: 40px;
  color: #fff;
`;

const SidebarButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  text-align: left;
  padding: 12px 18px;
  cursor: pointer;
  margin-bottom: 20px;
  width: 100%;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  & svg {
    margin-right: 10px;
  }
`;

const MainContent = styled.div`
  margin-left: 250px;
  padding: 20px;
  flex-grow: 1;
  background-color: #f4f7fc;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #007bff;
  color: white;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;

const TitleContainer = styled.div`
  display: flex;
  align-items: center;
`;

const Title = styled.h1`
  font-size: 28px;
  margin: 0;
  font-weight: 700;
  margin-right: 20px;
`;

const AccountContainer = styled.div`
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
`;

const AccountItem = styled.div`
  padding: 12px 20px;
  color: #333;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #f4f4f4;
  }
`;

const TripGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 20px;
`;

const TripCard = styled.div`
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  }
`;

const TripImage = styled.div`
  background: url('https://pbs.twimg.com/media/F7iSr7-WoAAqBAy?format=jpg&name=large') center/cover;
  height: 180px;
  border-radius: 12px 12px 0 0;
`;

const TripContent = styled.div`
  padding: 20px;
  text-align: center;
`;

const TripTitle = styled.h3`
  margin: 0;
  color: #007bff;
  font-size: 22px;
`;

const TripDetails = styled.p`
  color: #555;
  margin: 5px 0;
  font-size: 16px;
`;

const ButtonContainer = styled.div`
  display: flex;
  justify-content: space-around;
  padding: 15px;
  background-color: #f9f9f9;
  border-top: 1px solid #eee;
`;

const Button = styled.button`
  padding: 12px 20px;
  background-color: ${(props) => (props.primary ? '#007bff' : '#28a745')};
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 15px;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: ${(props) => (props.primary ? '#0056b3' : '#218838')};
    transform: scale(1.05);
  }
`;

const LoadingMessage = styled.div`
  margin-top: 50px;
  font-size: 18px;
  color: #666;
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 16px;
  margin-top: 20px;
`;

const GraphContainer = styled.div`
  margin-top: 30px;
  background-color: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  width: 80%; /* Reduce width to 80% */
  max-width: 1600px; /* Set max width */
  height: 600px; /* Set a fixed height */
  margin-left: auto;
  margin-right: auto;
`;

const AdminTripList = () => {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTrips = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/trips/list', {
          headers: {
            Authorization: localStorage.getItem('token'),
          },
        });
        setTrips(response.data);
      } catch (error) {
        setError('Failed to fetch trips. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTrips();
  }, []);

  const handleDetails = (tripId) => {
    navigate(`/admintrip/${tripId}`);
  };

  const handleAddStateroom = (tripId) => {
    navigate(`/stateroom/insert/${tripId}`);
  };

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  const handleInsertTrip = () => {
    navigate('/trip/insert');
  };

  const handleInsertRestaurant = () => {
    navigate('/restaurant/insert');
  };

  const handleInsertEntertainment = () => {
    navigate('/entertainment/insert');
  };

  return (
    <Container>
      <Sidebar>
        <SidebarTitle>Admin Dashboard</SidebarTitle>
        <SidebarButton onClick={handleInsertTrip}>
          <FaShip /> Add Trip
        </SidebarButton>
        <SidebarButton onClick={handleInsertRestaurant}>
          <FaUtensils /> Add Restaurant
        </SidebarButton>
        <SidebarButton onClick={handleInsertEntertainment}>
          <FaTheaterMasks /> Add Entertainment
        </SidebarButton>
        <SidebarButton onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </SidebarButton>
      </Sidebar>

      <MainContent>
        <Header>
          <TitleContainer>
            <Title>Available Trips</Title>
          </TitleContainer>
        </Header>

        {/* Graph Container */}
        <GraphContainer>
          <BookingTrendGraph />
        </GraphContainer>

        {loading ? (
          <LoadingMessage>Loading trips...</LoadingMessage>
        ) : error ? (
          <ErrorMessage>{error}</ErrorMessage>
        ) : (
          <TripGrid>
            {trips.map((trip) => (
              <TripCard key={trip.tripId}>
                <TripImage />
                <TripContent>
                  <TripTitle>{trip.startPort} to {trip.endPort}</TripTitle>
                  <TripDetails><strong>Duration:</strong> {trip.numNights} nights</TripDetails>
                  <TripDetails><strong>From:</strong> {new Date(trip.startDate).toLocaleDateString()}</TripDetails>
                  <TripDetails><strong>To:</strong> {new Date(trip.endDate).toLocaleDateString()}</TripDetails>
                </TripContent>
                <ButtonContainer>
                  <Button onClick={() => handleDetails(trip.tripId)} primary>
                    <FaInfoCircle /> Details
                  </Button>
                  <Button onClick={() => handleAddStateroom(trip.tripId)}>
                    <FaUserCircle /> Add Stateroom
                  </Button>
                </ButtonContainer>
              </TripCard>
            ))}
          </TripGrid>
        )}
      </MainContent>
    </Container>
  );
};

export default AdminTripList;
