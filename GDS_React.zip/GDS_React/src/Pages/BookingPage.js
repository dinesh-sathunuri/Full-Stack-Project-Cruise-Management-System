import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

// Styled Components
const Container = styled.div`
  padding: 20px;
  background: linear-gradient(to bottom, #f8fbff, #eef3f8);
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
`;

const Title = styled.h1`
  font-size: 28px;
  color: #1a202c;
  margin-bottom: 20px;
  text-align: center;
`;

const DetailsContainer = styled.div`
  background: white;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 700px;
  margin-bottom: 20px;
`;

const Section = styled.div`
  margin-bottom: 20px;
`;

const SectionTitle = styled.h2`
  font-size: 18px;
  color: #2d3748;
  border-bottom: 2px solid #edf2f7;
  padding-bottom: 8px;
  margin-bottom: 12px;
`;

const DetailItem = styled.p`
  color: #4a5568;
  font-size: 16px;
  margin: 5px 0;
  line-height: 1.5;
`;

const Highlight = styled.span`
  font-weight: bold;
  color: #2b6cb0;
`;

const PaymentSection = styled.div`
  margin: 20px 0;
  padding: 20px;
  background: #f7fafc;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 700px;
`;

const PaymentLabel = styled.label`
  display: block;
  font-size: 16px;
  color: #2d3748;
  margin-bottom: 10px;
`;

const Select = styled.select`
  width: 100%;
  padding: 10px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: white;
  font-size: 16px;
  color: #2d3748;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 16px;
  margin-bottom: 10px;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 15px;
  margin-top: 20px;
`;

const Button = styled.button`
  flex: 1;
  padding: 12px;
  background: #3182ce;
  color: white;
  font-size: 16px;
  font-weight: bold;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #2c5282;
  }

  &:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
  }
`;

const CancelButton = styled(Button)`
  background: #e53e3e;

  &:hover {
    background: #c53030;
  }
`;

const CostBreakdownBox = styled.div`
  margin: 20px 0;
  padding: 20px;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 700px;
`;

const BreakdownTitle = styled.h2`
  font-size: 20px;
  color: #2b6cb0;
  margin-bottom: 15px;
  text-align: center;
`;

const BreakdownItemContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 12px 0;
`;

const BreakdownItemLabel = styled.div`
  font-size: 16px;
  color: #4a5568;
  font-weight: 600;
`;

const BreakdownItemValue = styled.div`
  font-size: 16px;
  color: #2b6cb0;
  font-weight: 600;
`;

const BreakdownTotal = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  padding-top: 15px;
  border-top: 2px solid #cbd5e0;
  font-size: 18px;
  font-weight: 700;
  color: #2b6cb0;
`;

const BookingPage = () => {
  const [tripDetails, setTripDetails] = useState(null);
  const [selectedPackagesDetails, setSelectedPackagesDetails] = useState([]);
  const [selectedStateroomDetails, setSelectedStateroomDetails] = useState(null);
  const [totalCost, setTotalCost] = useState(0);
  const [errorMessage, setErrorMessage] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('credit');
  const [loading, setLoading] = useState(true);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTripDetails = async () => {
      setLoading(true);
      try {
        const tripId = localStorage.getItem('tripId');
        const response = await axios.get(`http://localhost:8080/api/trips/${tripId}`);
        setTripDetails(response.data);
      } catch (err) {
        setErrorMessage('Error fetching trip details');
      } finally {
        setLoading(false);
      }
    };

    fetchTripDetails();
  }, []);

  useEffect(() => {
    const fetchSelectedPackagesDetails = async () => {
      try {
        const selectedPackages = JSON.parse(localStorage.getItem('selectedPackages')) || [];
        const packageDetailsPromises = selectedPackages.map(pkg =>
          axios.get(`http://localhost:8080/api/trips/package/${pkg.packageId}`)
        );
        const responses = await Promise.all(packageDetailsPromises);
        setSelectedPackagesDetails(responses.map(res => res.data[0]));
      } catch (err) {
        console.error('Error fetching package details:', err);
      }
    };

    const fetchSelectedStateroomDetails = async () => {
      try {
        const stateroomId = localStorage.getItem('selectedStateroomId');
        const response = await axios.get(`http://localhost:8080/api/trips/stateroom/${stateroomId}`);
        setSelectedStateroomDetails(response.data[0]);
      } catch (err) {
        console.error('Error fetching stateroom details:', err);
      }
    };

    fetchSelectedPackagesDetails();
    fetchSelectedStateroomDetails();
  }, []);

  const handleEditGroup = () => navigate('/create-group');
  const handleEditPackagesAndStaterooms = () => navigate('/packages');
  
  useEffect(() => {
    if (!tripDetails) return; // Prevent calculation if tripDetails is not yet loaded
    const packageCost = selectedPackagesDetails.reduce((total, pkg) => total + (pkg.price * (pkg.quantity || 1)), 0);
    const stateroomCost = selectedStateroomDetails?.pricePerNight * tripDetails?.trip.numNights || 0;
    setTotalCost(packageCost + stateroomCost);
  }, [selectedPackagesDetails, selectedStateroomDetails, tripDetails]);

  const handleFinalizeBooking = async () => {
    const passengers = JSON.parse(localStorage.getItem('passengers')) || [];
    const passengerIds = passengers.map(passenger => passenger.passengerId);
    const bookingData = {
      booking: {
        tripId: localStorage.getItem('tripId'),
        stateroom_price_id: localStorage.getItem('selectedStateroomId'),
        totalPrice: totalCost,
        groupName: localStorage.getItem('groupName') || "Default Group",
        passengerIds: passengerIds,
        numMembers: passengerIds.length
      },
      packages: selectedPackagesDetails.map(pkg => ({
        packageId: pkg.packageId,
        quantity: pkg.quantity || 1
      })),
      paymentMethod: paymentMethod
    };
  
    console.log('Booking Request Data:', JSON.stringify(bookingData, null, 2));
  
    if (!bookingData.booking.tripId || !bookingData.booking.stateroom_price_id) {
      setErrorMessage("Please ensure all booking details are filled in correctly.");
      return;
    }
  
    try {
      const response = await axios.post(`http://localhost:8080/api/bookings/create`, bookingData);
      alert('Your booking is finalized! Booking ID: ' + response.data.bookingId);
      navigate('/recent-booking');
    } catch (error) {
      console.error('Error finalizing booking:', error);
      if (error.response) {
        console.error('Response data:', error.response.data);
        setErrorMessage('Error finalizing booking: ' + (error.response.data.message || 'Unknown error'));
      } else {
        setErrorMessage('Error finalizing booking: No response received');
      }
    }
  };

  const handleCancelBooking = () => navigate('/home'); 

  if (loading) {
    return <Container><Title>Loading...</Title></Container>;
  }

  if (errorMessage) {
    return <Container><Title>Error</Title><p>{errorMessage}</p></Container>;
  }

  const groupName = localStorage.getItem('groupName');
  const passengers = JSON.parse(localStorage.getItem('passengers')) || [];

  return (
    <Container>
      <Title>Booking Summary</Title>
      <DetailsContainer>
        <Section>
          <SectionTitle>Trip Details</SectionTitle>
          <DetailItem><Highlight>From:</Highlight> {tripDetails.trip.startPort}</DetailItem>
          <DetailItem><Highlight>To:</Highlight> {tripDetails.trip.endPort}</DetailItem>
          <DetailItem><Highlight>Duration:</Highlight> {tripDetails.trip.numNights} nights</DetailItem>
          <DetailItem><Highlight>Start Date:</Highlight> {new Date(tripDetails.trip.startDate).toLocaleDateString()}</DetailItem>
          <DetailItem><Highlight>End Date:</Highlight> {new Date(tripDetails.trip.endDate).toLocaleDateString()}</DetailItem>
        </Section>
        <Section>
          <SectionTitle>Group Name</SectionTitle>
          <DetailItem><Highlight>Group Name:</Highlight> {groupName || "Not set"}</DetailItem>
        </Section>

        <Section>
          <SectionTitle>Group Members</SectionTitle>
          {passengers.length > 0 ? (
            passengers.map((passenger, index) => (
              <DetailItem key={index}>
                {passenger.firstName} {passenger.lastName} {passenger.email}
              </DetailItem>
            ))
          ) : (
            <DetailItem>No group members added.</DetailItem>
          )}
        </Section>

        <Section>
          <SectionTitle>Selected Stateroom</SectionTitle>
          {selectedStateroomDetails ? (
            <>
              <DetailItem><Highlight>Type:</Highlight> {selectedStateroomDetails.type_name}</DetailItem>
              <DetailItem><Highlight>Price per Night:</Highlight> ${selectedStateroomDetails.pricePerNight}</DetailItem>
            </>
          ) : (
            <DetailItem>No stateroom selected.</DetailItem>
          )}
        </Section>

        <Section>
          <SectionTitle>Selected Packages</SectionTitle>
          {selectedPackagesDetails.length > 0 ? (
            selectedPackagesDetails.map(pkg => (
              <DetailItem key={pkg.packageId}>
                {pkg.pkType} - ${pkg.price} (Quantity: {pkg.quantity || 1})
              </DetailItem>
            ))
          ) : (
            <DetailItem>No packages selected.</DetailItem>
          )}
        </Section>
      </DetailsContainer>

      <CostBreakdownBox>
        <BreakdownTitle>Total Cost</BreakdownTitle>
        <BreakdownItemContainer>
          <BreakdownItemLabel>Stateroom</BreakdownItemLabel>
          <BreakdownItemValue>${(selectedStateroomDetails?.pricePerNight * tripDetails.trip.numNights).toFixed(2)}</BreakdownItemValue>
        </BreakdownItemContainer>

        {selectedPackagesDetails.map(pkg => (
          <BreakdownItemContainer key={pkg.packageId}>
            <BreakdownItemLabel>{pkg.pkType}</BreakdownItemLabel>
            <BreakdownItemValue>${(pkg.price * (pkg.quantity || 1)).toFixed(2)}</BreakdownItemValue>
          </BreakdownItemContainer>
        ))}

        <BreakdownTotal>
          <BreakdownItemLabel>Total Cost</BreakdownItemLabel>
          <BreakdownItemValue>${totalCost.toFixed(2)}</BreakdownItemValue>
        </BreakdownTotal>
      </CostBreakdownBox>

      <PaymentSection>
        <PaymentLabel>Payment Method</PaymentLabel>
        <Select 
          value={paymentMethod} 
          onChange={(e) => setPaymentMethod(e.target.value)}
        >
          <option value="credit">Credit Card</option>
          <option value="paypal">PayPal</option>
        </Select>

        {paymentMethod === 'credit' && (
          <>
            <PaymentLabel>Card Number</PaymentLabel>
            <Input 
              type="text" 
              placeholder="Enter your card number" 
              value={cardNumber} 
              onChange={(e) => setCardNumber(e.target.value)} 
            />
            <PaymentLabel>Expiry Date</PaymentLabel>
            <Input 
              type="text" 
              placeholder="MM/YY" 
              value={expiryDate} 
              onChange={(e) => setExpiryDate(e.target.value)} 
            />
            <PaymentLabel>CVV</PaymentLabel>
            <Input 
              type="text" 
              placeholder="Enter CVV" 
              value={cvv} 
              onChange={(e) => setCvv(e.target.value)} 
            />
          </>
        )}
      </PaymentSection>

      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>} {/* Display error messages */}
      
      <ButtonGroup>
      <Button onClick={handleEditGroup}>Edit Group</Button>
        <Button onClick={handleEditPackagesAndStaterooms}>Edit Packages & Stateroom</Button>
        <Button onClick={handleFinalizeBooking}>Finalize Booking</Button>
        <CancelButton onClick={handleCancelBooking}>Cancel</CancelButton>
      </ButtonGroup>
    </Container>
  );
};

export default BookingPage;
