import React, { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import ClipLoader from 'react-spinners/ClipLoader';

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #e9f6ff;
  padding: 20px;
  box-sizing: border-box;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  background: #ffffff;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 500px;
`;

const Input = styled.input`
  padding: 10px;
  width: 100%;
  border: 1px solid #cccccc;
  border-radius: 5px;
  font-size: 1rem;

  &:focus {
    border-color: #1e90ff;
    outline: none;
    box-shadow: 0 0 5px rgba(30, 144, 255, 0.5);
  }
`;

const Select = styled.select`
  padding: 10px;
  width: 100%;
  border: 1px solid #cccccc;
  border-radius: 5px;
  font-size: 1rem;

  &:focus {
    border-color: #1e90ff;
    outline: none;
    box-shadow: 0 0 5px rgba(30, 144, 255, 0.5);
  }
`;

const Button = styled.button`
  padding: 10px;
  width: 100%;
  background-color: ${(props) => (props.disabled ? '#cccccc' : '#4caf50')};
  color: white;
  border: none;
  border-radius: 5px;
  cursor: ${(props) => (props.disabled ? 'not-allowed' : 'pointer')};
  font-size: 1rem;

  &:hover {
    background-color: ${(props) => (props.disabled ? '#cccccc' : '#45a049')};
  }
`;

const Title = styled.h1`
  color: #333;
  margin-bottom: 1rem;
  font-size: 2rem;
  text-align: center;
`;

const Message = styled.p`
  margin-top: 1rem;
  color: ${(props) => (props.error ? '#d9534f' : '#5cb85c')};
  font-size: 0.9rem;
  text-align: center;
`;

const RegisterPage = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [streetAddress, setStreetAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [country, setCountry] = useState('United States');
  const [gender, setGender] = useState('');
  const [email, setEmail] = useState('');
  const [nationality, setNationality] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [isOtpVerified, setIsOtpVerified] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const navigate = useNavigate();

  const isUnder13 = (dob) => {
    const birthDate = new Date(dob);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    const dayDiff = today.getDate() - birthDate.getDate();
    return age < 13 || (age === 13 && monthDiff <= 0 && dayDiff <= 0);
  };

  const generateRandomEmail = () => {
    const randomSuffix = Math.floor(Math.random() * 10000);
    return `user${randomSuffix}@nice.com`;
  };
  const generateConstantEmail = (firstName, lastName, dob) => {
    if (!firstName || !lastName || !dob) return ''; // Safeguard against incomplete inputs
    const uniqueSuffix = `${firstName.toLowerCase()}.${lastName.toLowerCase()}.${dob.replace(/-/g, '')}`;
    return `under13_${uniqueSuffix}@nice.com`;
  };
  const handleSendOtp = async () => {
    if (!email) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    setOtpLoading(true);
    setErrorMessage('');

    try {
      const response = await fetch(`http://localhost:8080/passenger/api/send-otp-register/${encodeURIComponent(email)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setIsOtpSent(true);
        setErrorMessage('');
      } else {
        const message = await response.text();
        setErrorMessage(message);
      }
    } catch (error) {
      setErrorMessage('Failed to send OTP. Please try again.');
    } finally {
      setOtpLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:8080/passenger/api/verify-otp?email=${encodeURIComponent(email)}&otp=${encodeURIComponent(otp)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setIsOtpVerified(true);
        setOtp('');
        setErrorMessage('');
      } else {
        const message = await response.text();
        setErrorMessage(message);
      }
    } catch (error) {
      setErrorMessage('Failed to verify OTP. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (isUnder13(dateOfBirth)) {
      const constantEmail = generateConstantEmail(firstName, lastName, dateOfBirth);
      setEmail(constantEmail); 
      setIsOtpVerified(true);
    }

    if (!isOtpVerified && !isUnder13(dateOfBirth)) {
      setErrorMessage('Please verify your OTP first.');
      return;
    }
    setLoading(true);
    const passengerData = {
      first_name:firstName,
      last_name:lastName,
      date_of_birth:dateOfBirth,
      street_address:streetAddress,
      city,
      state,
      zip_code:zipCode,
      country,
      gender,
      email,
      nationality,
      phone,
    };

    try {
      const response = await fetch('http://localhost:8080/passenger/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(passengerData),
      });

      if (response.ok) {
        navigate('/');
      } else {
        const message = await response.text();
        setErrorMessage(message);
      }
    } catch (error) {
      setErrorMessage('Failed to register. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container>
      <Title>Register Passenger</Title>
      <Form onSubmit={handleRegister}>
        <Input type="text" placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
        <Input type="text" placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
        <Input type="date" placeholder="Date of Birth" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} required />
        <Input type="text" placeholder="Street Address" value={streetAddress} onChange={(e) => setStreetAddress(e.target.value)} required />
        <Input type="text" placeholder="City" value={city} onChange={(e) => setCity(e.target.value)} required />
        <Input type="text" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} required />
        <Input type="text" placeholder="Zip Code" value={zipCode} onChange={(e) => setZipCode(e.target.value)} required />
        <Select value={country} onChange={(e) => setCountry(e.target.value)} required>
          <option value="United States">United States</option>
          <option value="Canada">Canada</option>
          <option value="Mexico">Mexico</option>
        </Select>
        <Select value={gender} onChange={(e) => setGender(e.target.value)} required>
          <option value="">Select Gender</option>
          <option value="M">Male</option>
          <option value="F">Female</option>
          <option value="O">Other</option>
        </Select>
        <Input type="text" placeholder="Nationality" value={nationality} onChange={(e) => setNationality(e.target.value)} required />
        <Input type="tel" placeholder="Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} required />
        <Input
          type="email"
          placeholder="Email"
          value={
            isUnder13(dateOfBirth)
              ? generateConstantEmail(firstName, lastName, dateOfBirth)
              : email
          }
          onChange={(e) => !isUnder13(dateOfBirth) && setEmail(e.target.value)}
          readOnly={isUnder13(dateOfBirth)} // Prevent manual input for under-13 users
          required
        />
        {!isUnder13(dateOfBirth) && (
          <Button type="button" onClick={handleSendOtp} disabled={!email || otpLoading || isOtpVerified}>
            {otpLoading ? <ClipLoader size={15} color="white" /> : 'Send OTP'}
          </Button>
        )}

        {isOtpSent && !isOtpVerified && !isUnder13(dateOfBirth) && (
          <>
            <Input type="text" placeholder="Enter OTP" value={otp} onChange={(e) => setOtp(e.target.value)} required />
            <Button type="button" onClick={handleVerifyOtp} disabled={loading}>
              {loading ? <ClipLoader size={15} color="white" /> : 'Verify OTP'}
            </Button>
          </>
        )}

        <Button type="submit" disabled={loading || (!isOtpVerified && !isUnder13(dateOfBirth))}>
          {loading ? <ClipLoader size={15} color="white" /> : 'Register'}
        </Button>

        {errorMessage && <Message error>{errorMessage}</Message>}
      </Form>
    </Container>
  );
};

export default RegisterPage;