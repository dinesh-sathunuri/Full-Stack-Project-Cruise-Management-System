import React, { useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { FaHome, FaSignOutAlt, FaTheaterMasks,FaShip } from 'react-icons/fa';

const Container = styled.div`
  display: flex;
  min-height: 100vh;
  font-family: 'Roboto', sans-serif;
`;

const Sidebar = styled.div`
  width: 225px;
  background: linear-gradient(180deg, #007bff, #0056b3);
  padding: 20px;
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  height: 100%;
  top: 0;
  left: 0;
  box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
`;

const SidebarTitle = styled.h2`
  font-size: 26px;
  font-weight: 700;
  margin-bottom: 40px;
  color: #fff;
`;

const SidebarButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  text-align: left;
  padding: 12px 18px;
  cursor: pointer;
  margin-bottom: 20px;
  width: 100%;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  & svg {
    margin-right: 10px;
  }
`;

const MainContent = styled.div`
  margin-left: 250px;
  padding: 20px;
  flex-grow: 1;
  background-color: #f4f7fc;
`;

const Title = styled.h1`
  text-align: center;
  color: #007bff;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`;

const Label = styled.label`
  font-size: 16px;
  color: #333;
`;

const Input = styled.input`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Select = styled.select`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Button = styled.button`
  padding: 10px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 14px;
  margin-top: 10px;
`;

const SuccessMessage = styled.div`
  color: green;
  font-size: 14px;
  margin-top: 10px;
`;

const InsertRestaurant = () => {
  const [rtName, setRtName] = useState('');
  const [rtType, setRtType] = useState('');
  const [rtFloor, setRtFloor] = useState('');
  const [openingTime, setOpeningTime] = useState('');
  const [closingTime, setClosingTime] = useState('');
  const [servesBreakfast, setServesBreakfast] = useState(0);
  const [servesLunch, setServesLunch] = useState(0);
  const [servesDinner, setServesDinner] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validate input fields
    if (!rtName || !rtType || !rtFloor || !openingTime || !closingTime) {
      setError('Please fill in all fields.');
      return;
    }
    const formattedOpeningTime = new Date(`1970-01-01T${openingTime}:00Z`).toISOString();
    const formattedClosingTime = new Date(`1970-01-01T${closingTime}:00Z`).toISOString();
    try {
      const response = await axios.post(
        'http://localhost:8080/api/trips/restaurant/insert',
        {
          rtName,
          rtType,
          rtFloor,
          openingTime: formattedOpeningTime,
          closingTime: formattedClosingTime,
          servesBreakfast,
          servesLunch,
          servesDinner,
        },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setSuccess('Restaurant added successfully.');
      setTimeout(() => navigate('/adminhome'), 2000); // Navigate after 2 seconds
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add restaurant.');
    }
  };

  const handleHome = () => {
    navigate('/adminhome');
  };
  const handleInsertTrip = () => {
    navigate('/trip/insert');
  };
  const handleInsertEntertainment = () => {
    navigate('/entertainment/insert');
  };
  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  return (
    <Container>
      <Sidebar>
        <SidebarTitle>Admin Dashboard</SidebarTitle>
        <SidebarButton onClick={handleHome}>
          <FaHome /> Home
        </SidebarButton>
        <SidebarButton onClick={handleInsertTrip}>
          <FaShip /> Add Trip
        </SidebarButton>
        <SidebarButton onClick={handleInsertEntertainment}>
          <FaTheaterMasks /> Add Entertainment
        </SidebarButton>
        <SidebarButton onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </SidebarButton>
      </Sidebar>

      <MainContent>
        <Title>Insert Restaurant</Title>
        <Form onSubmit={handleSubmit}>
          <Label htmlFor="rtName">Restaurant Name</Label>
          <Input
            type="text"
            id="rtName"
            value={rtName}
            onChange={(e) => setRtName(e.target.value)}
            required
          />

          <Label htmlFor="rtType">Restaurant Type</Label>
          <Input
            type="text"
            id="rtType"
            value={rtType}
            onChange={(e) => setRtType(e.target.value)}
            required
          />

          <Label htmlFor="rtFloor">Restaurant Floor</Label>
          <Input
            type="number"
            id="rtFloor"
            value={rtFloor}
            onChange={(e) => setRtFloor(e.target.value)}
            required
            min="1"
          />

          <Label htmlFor="openingTime">Opening Time</Label>
          <Input
            type="time"
            id="openingTime"
            value={openingTime}
            onChange={(e) => setOpeningTime(e.target.value)}
            required
          />

          <Label htmlFor="closingTime">Closing Time</Label>
          <Input
            type="time"
            id="closingTime"
            value={closingTime}
            onChange={(e) => setClosingTime(e.target.value)}
            required
          />

          <Label htmlFor="servesBreakfast">Serves Breakfast</Label>
          <Select
            id="servesBreakfast"
            value={servesBreakfast}
            onChange={(e) => setServesBreakfast(Number(e.target.value))}
          >
            <option value="0">No</option>
            <option value="1">Yes</option>
          </Select>

          <Label htmlFor="servesLunch">Serves Lunch</Label>
          <Select
            id="servesLunch"
            value={servesLunch}
            onChange={(e) => setServesLunch(Number(e.target.value))}
          >
            <option value="0">No</option>
            <option value="1">Yes</option>
          </Select>

          <Label htmlFor="servesDinner">Serves Dinner</Label>
          <Select
            id="servesDinner"
            value={servesDinner}
            onChange={(e) => setServesDinner(Number(e.target.value))}
          >
            <option value="0">No</option>
            <option value="1">Yes</option>
          </Select>

          {error && <ErrorMessage>{error}</ErrorMessage>}
          {success && <SuccessMessage>{success}</SuccessMessage>}

          <Button type="submit">Add Restaurant</Button>
        </Form>
      </MainContent>
    </Container>
  );
};

export default InsertRestaurant;
