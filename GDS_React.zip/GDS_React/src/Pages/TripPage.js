// src/Pages/TripPage.js

import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import styled from 'styled-components';
import { FaRocket, FaUtensils, FaFilm } from 'react-icons/fa';

const PageWrapper = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 2rem;
    background-color: #e8f4fa;
    min-height: 100vh;
    font-family: 'Roboto', sans-serif;
`;

const Header = styled.h1`
    font-size: 2.8rem;
    color: #2c3e50;
    margin-bottom: 0.5rem;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 2px;
`;

const Subtitle = styled.p`
    font-size: 1.2rem;
    color: #34495e;
    margin-bottom: 2rem;
    text-align: center;
`;

const SectionWrapper = styled.div`
    display: flex;
    flex-direction: column;
    gap: 2rem;
    width: 100%;
    max-width: 800px;
`;

const Section = styled.div`
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    padding: 2rem;
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.20);
    }
`;

const SectionTitle = styled.h2`
    font-size: 2rem;
    color: #3498db;
    margin-bottom: 1rem;
    border-bottom: 3px solid #3498db;
    padding-bottom: 0.5rem;
    display: flex;
    align-items: center;
`;

const InfoRow = styled.div`
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
    padding: 0.5rem 0;
    border-bottom: 1px solid #f0f0f0;
`;

const Label = styled.span`
    font-weight: bold;
    color: #34495e;
    font-size: 1.1rem;
`;

const Value = styled.span`
    color: #7f8c8d;
    font-size: 1.1rem;
`;

const CardGrid = styled.div`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
`;

const Card = styled.div`
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    &:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }
`;

const CardHeader = styled.h3`
    font-size: 1.5rem;
    color: #34495e;
    margin-bottom: 0.5rem;
    text-transform: capitalize;
    display: flex;
    align-items: center;
`;

const CardDetail = styled.p`
    margin: 0.3rem 0;
    font-size: 1rem;
    color: #7f8c8d;
`;

const ErrorMessage = styled.p`
    color: #e74c3c;
    font-size: 1.2rem;
    text-align: center;
    font-weight: bold;
`;

const LoadingMessage = styled.p`
    font-size: 1.2rem;
    color: #7f8c8d;
    text-align: center;
`;

const TripPage = () => {
    const { tripId } = useParams();
    const [tripDetails, setTripDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchTripDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/api/trips/${tripId}`);
                setTripDetails(response.data);
            } catch (err) {
                setError('Failed to load trip details');
            } finally {
                setLoading(false);
            }
        };

        fetchTripDetails();
    }, [tripId]);

    if (loading) return <LoadingMessage>Loading trip details...</LoadingMessage>;
    if (error) return <ErrorMessage>{error}</ErrorMessage>;

    return (
        <PageWrapper>
            <Header>Trip Details</Header>
            <Subtitle>Explore all the details about your trip.</Subtitle>
            <SectionWrapper>
                {/* Trip Info */}
                <Section>
                    <SectionTitle>
                        <FaRocket style={{ marginRight: '10px' }} /> Trip Information
                    </SectionTitle>
                    <InfoRow>
                        <Label>Start Port:</Label>
                        <Value>{tripDetails.trip.startPort}</Value>
                    </InfoRow>
                    <InfoRow>
                        <Label>End Port:</Label>
                        <Value>{tripDetails.trip.endPort}</Value>
                    </InfoRow>
                    <InfoRow>
                        <Label>Number of Nights:</Label>
                        <Value>{tripDetails.trip.numNights}</Value>
                    </InfoRow>
                    <InfoRow>
                        <Label>Start Date:</Label>
                        <Value>{new Date(tripDetails.trip.startDate).toLocaleDateString()}</Value>
                    </InfoRow>
                    <InfoRow>
                        <Label>End Date:</Label>
                        <Value>{new Date(tripDetails.trip.endDate).toLocaleDateString()}</Value>
                    </InfoRow>
                </Section>

                {/* Restaurants */}
                <Section>
                    <SectionTitle>
                        <FaUtensils style={{ marginRight: '10px' }} /> Restaurants
                    </SectionTitle>
                    <CardGrid>
                        {tripDetails.restaurants.map((restaurant) => (
                            <Card key={restaurant.restaurantId}>
                                <CardHeader>{restaurant.rtName} ({restaurant.rtType})</CardHeader>
                                <CardDetail><Label>Floor:</Label> {restaurant.rtFloor}</CardDetail>
                                <CardDetail>
                                    <Label>Opening Time:</Label>{' '}
                                    {new Date(restaurant.openingTime).toLocaleTimeString()}
                                </CardDetail>
                                <CardDetail>
                                    <Label>Closing Time:</Label>{' '}
                                    {new Date(restaurant.closingTime).toLocaleTimeString()}
                                </CardDetail>
                            </Card>
                        ))}
                    </CardGrid>
                </Section>

                {/* Entertainment */}
                <Section>
                    <SectionTitle>
                        <FaFilm style={{ marginRight: '10px' }} /> Entertainment
                    </SectionTitle>
                    <CardGrid>
                        {tripDetails.entertainments.map((entertainment) => (
                            <Card key={entertainment.entertainmentId}>
                                <CardHeader>{entertainment.etType}</CardHeader>
                                <CardDetail><Label>Number of Units:</Label> {entertainment.numUnits}</CardDetail>
                                <CardDetail><Label>Floor:</Label> {entertainment.etFloor}</CardDetail>
                                <CardDetail><Label>Age Restriction:</Label> {entertainment.ageRestriction}+</CardDetail>
                            </Card>
                        ))}
                    </CardGrid>
                </Section>
            </SectionWrapper>
        </PageWrapper>
    );
};

export default TripPage;