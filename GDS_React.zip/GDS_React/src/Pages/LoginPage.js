import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

// Styled Components
const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: url('') no-repeat center center fixed;
  background-size: cover; /* Make background cover the entire container */
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  background: rgba(255, 255, 255, 0.9); /* Slight transparency for background */
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 90%;
  max-width: 400px;

  @media (max-width: 400px) {
    padding: 1rem;
  }
`;

const Input = styled.input`
  padding: 10px;
  border: 1px solid #cccccc;
  border-radius: 4px;

  &:focus {
    border-color: #4caf50;
    outline: none;
  }
`;

const Button = styled.button`
  padding: 10px;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #45a049;
  }

  &:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
  }
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 14px;
  text-align: center;
`;

const OTPMessage = styled.p`
  font-size: 14px;
  color: #007bff;
  text-align: center;
`;

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [step, setStep] = useState('login'); // 'login' or 'otp'
  const navigate = useNavigate();

  useEffect(() => {
    Cookies.remove('sessionId');
  }, []);

  const sendOtp = async (emailToSend) => {
    setLoading(true);
    setErrorMessage('');

    if (!validateEmail(emailToSend)) {
      setErrorMessage('Please enter a valid email address.');
      setLoading(false);
      return;
    }
    if(emailToSend.endsWith('@nice.com'))
    {
      alert('This mail Not for login');
      navigate('/');
      setLoading(false);
      return;
    }
    // Check if the email ends with nyu.edu
    if (email==='ds7675@nyu.edu') {
      Cookies.set('sessionId', emailToSend, { expires: 1 });
      navigate('/adminhome');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(`http://localhost:8080/passenger/api/send-otp?email=${encodeURIComponent(emailToSend)}`, {
        method: 'POST',
      });

      if (response.ok) {
        setStep('otp');
        setErrorMessage('OTP sent successfully! Check your inbox.');
      } else {
        // If the response is not OK, check the status for specific errors
        if (response.status === 400) {
          alert('This email is not registered. Please sign up.');
          navigate('/register');
        } else {
          const data = await response.json();
          setErrorMessage(data.message || 'Failed to send OTP.');
        }
      }
    } catch (error) {
      console.error('Error in sending OTP:', error);
      setErrorMessage('Network issue. Could not send OTP.');
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    try {
      const response = await fetch(
        `http://localhost:8080/passenger/api/verify-otp?email=${encodeURIComponent(email)}&otp=${encodeURIComponent(otp)}`,
        {
          method: 'POST',
        }
      );

      if (response.ok) {
        Cookies.set('sessionId', email, { expires: 1 });
        navigate('/home');
      } else {
        const data = await response.json();
        setErrorMessage(data.message || 'Invalid OTP');
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
      setErrorMessage('Failed to verify OTP.');
    } finally {
      setLoading(false);
    }
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  return (
    <Container>
      {errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}

      {step === 'login' && (
        <Form onSubmit={(e) => {
          e.preventDefault();
          sendOtp(email);
        }}>
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button disabled={loading}>{loading ? 'Sending OTP...' : 'Login'}</Button>
          <Button
            type="button"
            onClick={() => {
              navigate('/register')
            }}
            disabled={loading}
          >
            Register
          </Button>
        </Form>
      )}

      {step === 'otp' && (
        <Form onSubmit={handleOtpSubmit}>
          <Input
            type="text"
            placeholder="Enter OTP sent to email"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            required
          />
          <Button disabled={loading}>{loading ? 'Verifying...' : 'Verify OTP'}</Button>
          <OTPMessage>If you didn't receive the OTP, check your email inbox or spam folder.</OTPMessage>
        </Form>
      )}
    </Container>
  );
};

export default LoginPage;
