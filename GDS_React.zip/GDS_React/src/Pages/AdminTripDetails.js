import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const AdminTripDetails = () => {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [entertainmentSchedule, setEntertainmentSchedule] = useState([]);
  const [restaurantSchedule, setRestaurantSchedule] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    // Fetch Entertainment Schedule
    fetch(`http://localhost:8080/api/trips/Scheduled/entertainment/${tripId}`)
      .then((response) => response.json())
      .then((data) => {
        const filteredData = data.filter((item) => item.tripId === parseInt(tripId));
        setEntertainmentSchedule(filteredData);
      })
      .catch((error) => setError("Error fetching entertainment schedule"));

    // Fetch Restaurant Schedule
    fetch(`http://localhost:8080/api/trips/Scheduled/restaurant/${tripId}`)
      .then((response) => response.json())
      .then((data) => setRestaurantSchedule(data))
      .catch((error) => setError("Error fetching restaurant schedule"));
  }, [tripId]);

  // Handlers for adding a restaurant or entertainment
  const handleAddRestaurant = () => {
    navigate(`/add-restaurant/${tripId}`);
  };

  const handleAddEntertainment = () => {
    navigate(`/add-entertainment/${tripId}`);
  };

  // Handler for the back button
  const handleBack = () => {
    navigate("/adminhome");
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Admin Trip Details</h1>
      <h2 className="text-muted text-center">Trip ID: {tripId}</h2>

      {/* Error Message */}
      {error && <div className="alert alert-danger text-center">{error}</div>}

      {/* Action Buttons */}
      <div className="text-center my-4">
        <button className="btn btn-primary me-3" onClick={handleAddRestaurant}>
          Add New Restaurant
        </button>
        <button className="btn btn-secondary" onClick={handleAddEntertainment}>
          Add New Entertainment
        </button>
      </div>

      {/* Back Button */}
      <div className="text-center my-3">
        <button className="btn btn-warning" onClick={handleBack}>
          Back to Admin Home
        </button>
      </div>

      {/* Entertainment Schedule */}
      <section className="mt-4">
        <h3 className="mb-3 text-primary">Entertainment Schedule</h3>
        {entertainmentSchedule.length > 0 ? (
          <div className="row">
            {entertainmentSchedule.map((item, index) => (
              <div key={index} className="col-md-6">
                <div className="card mb-4 shadow-sm">
                  <div className="card-body">
                    <h5 className="card-title">{item.entertainment.etType}</h5>
                    <p className="card-text">
                      <strong>Date:</strong> {item.schedule} <br />
                      <strong>Floor:</strong> {item.entertainment.etFloor} <br />
                      <strong>Units:</strong> {item.entertainment.numUnits} <br />
                      <strong>Age Restriction:</strong> {item.entertainment.ageRestriction}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted">No entertainment schedule found.</p>
        )}
      </section>

      {/* Restaurant Schedule */}
      <section className="mt-4">
        <h3 className="mb-3 text-primary">Restaurant Schedule</h3>
        {restaurantSchedule.length > 0 ? (
          <div className="row">
            {restaurantSchedule.map((item) => (
              <div key={item.restaurantScheduleId} className="col-md-6">
                <div className="card mb-4 shadow-sm">
                  <div className="card-body">
                    <h5 className="card-title">{item.restaurant.rtName}</h5>
                    <p className="card-text">
                      <strong>Date:</strong> {item.scheduleDate} <br />
                      <strong>Meal Type:</strong> {item.mealType} <br />
                      <strong>Type:</strong> {item.restaurant.rtType} <br />
                      <strong>Floor:</strong> {item.restaurant.rtFloor} <br />
                      <strong>Opening Time:</strong>{" "}
                      {new Date(item.restaurant.openingTime).toLocaleTimeString()} <br />
                      <strong>Closing Time:</strong>{" "}
                      {new Date(item.restaurant.closingTime).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted">No restaurant schedule found.</p>
        )}
      </section>
    </div>
  );
};

export default AdminTripDetails;
