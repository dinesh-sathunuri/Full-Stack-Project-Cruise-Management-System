import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams,useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const Container = styled.div`
  width: 50%;
  margin: 50px auto;
  padding: 20px;
  border-radius: 10px;
  background-color: #f8f9fa;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #007bff;
  color: white;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;
const FormTitle = styled.h1`
font-size: 28px;
margin: 0;
font-weight: 700;
text-align: center;
`;

const Label = styled.label`
  font-size: 16px;
  margin: 10px 0;
  display: block;
`;

const Input = styled.input`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

const Select = styled.select`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  margin-bottom: 20px;
  border-radius: 8px;
  border: 1px solid #ccc;
`;

const Button = styled.button`
  padding: 12px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  display: flex;
  align-items: center;
  justify-content: center;
`;

const ErrorMessage = styled.div`
  color: red;
  text-align: center;
  margin-top: 20px;
`;

const InsertStateroomPrice = () => {
  const { tripId } = useParams();
  const [staterooms, setStaterooms] = useState([]);
  const [stateroomId, setStateroomId] = useState('');
  const [locationSide, setLocationSide] = useState('');
  const [pricePerNight, setPricePerNight] = useState('');
  const [numUnits, setNumUnits] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch staterooms from the API to populate the dropdown
    const fetchStaterooms = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/trips/stateroom');
        setStaterooms(response.data);  // Store stateroom data in the state
      } catch (err) {
        setError('Failed to fetch staterooms. Please try again later.');
      }
    };

    fetchStaterooms();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Form validation
    if (!stateroomId || !tripId || !locationSide || !pricePerNight || !numUnits) {
      setError('All fields are required');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8080/api/trips/stateroomPrice/insert', {
        stateroomId: stateroomId,
        tripId: tripId,
        locationSide: locationSide,
        pricePerNight: parseFloat(pricePerNight),
        numUnits: parseInt(numUnits),
      });

      if (response.status === 200) {
        alert('Stateroom price inserted successfully!');
        navigate('/adminhome');  // Navigate to the trip list or another page
      }
    } catch (err) {
      setError('Failed to insert stateroom price. Please try again later.');
    }
  };

  return (
    <Container>
    <Header>
      <FormTitle>Insert Stateroom Price</FormTitle>
      </Header>
      <form onSubmit={handleSubmit}>
        <Label htmlFor="stateroomId">Stateroom</Label>
        <Select
          id="stateroomId"
          value={stateroomId}
          onChange={(e) => setStateroomId(e.target.value)}
        >
          <option value="">Select Stateroom</option>
          {staterooms.map((stateroom) => (
            <option key={stateroom.stateroomId} value={stateroom.stateroomId}>
              {stateroom.type_name} ({stateroom.sizeSqft} sqft, {stateroom.numBeds} beds)
            </option>
          ))}
        </Select>

        <Label htmlFor="locationSide">Location Side</Label>
        <Select
          id="locationSide"
          value={locationSide}
          onChange={(e) => setLocationSide(e.target.value)}
        >
          <option value="">Select Side</option>
          <option value="Forward">Forward</option>
          <option value="After">After</option>
          <option value="Left">Left</option>
          <option value="Right">Right</option>
        </Select>

        <Label htmlFor="pricePerNight">Price per Night ($)</Label>
        <Input
          id="pricePerNight"
          type="number"
          step="0.01"
          value={pricePerNight}
          onChange={(e) => setPricePerNight(e.target.value)}
        />

        <Label htmlFor="numUnits">Number of Units</Label>
        <Input
          id="numUnits"
          type="number"
          value={numUnits}
          onChange={(e) => setNumUnits(e.target.value)}
        />

        {error && <ErrorMessage>{error}</ErrorMessage>}

        <Button type="submit">Submit</Button>
      </form>
    </Container>
  );
};

export default InsertStateroomPrice;
