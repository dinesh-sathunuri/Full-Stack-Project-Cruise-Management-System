import React, { useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { FaHome, FaSignOutAlt, FaTheaterMasks,FaShip,FaUtensils } from 'react-icons/fa';

const Container = styled.div`
  display: flex;
  min-height: 100vh;
  font-family: 'Roboto', sans-serif;
`;

const Sidebar = styled.div`
  width: 225px;
  background: linear-gradient(180deg, #007bff, #0056b3);
  padding: 20px;
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  height: 100%;
  top: 0;
  left: 0;
  box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
`;

const SidebarTitle = styled.h2`
  font-size: 26px;
  font-weight: 700;
  margin-bottom: 40px;
  color: #fff;
`;

const SidebarButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  text-align: left;
  padding: 12px 18px;
  cursor: pointer;
  margin-bottom: 20px;
  width: 100%;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  & svg {
    margin-right: 10px;
  }
`;

const MainContent = styled.div`
  margin-left: 250px;
  padding: 20px;
  flex-grow: 1;
  background-color: #f4f7fc;
`;

const Title = styled.h1`
  text-align: center;
  color: #007bff;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`;

const Label = styled.label`
  font-size: 16px;
  color: #333;
`;

const Input = styled.input`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Select = styled.select`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Button = styled.button`
  padding: 10px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 14px;
  margin-top: 10px;
`;

const SuccessMessage = styled.div`
  color: green;
  font-size: 14px;
  margin-top: 10px;
`;

const InsertEntertainment = () => {
  const [etType, setEtType] = useState('');
  const [numUnits, setNumUnits] = useState('');
  const [etFloor, setEtFloor] = useState('');
  const [ageRestriction, setAgeRestriction] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validate input fields
    if (!etType || !numUnits || !etFloor || !ageRestriction) {
      setError('Please fill in all fields.');
      return;
    }

    try {
      const response = await axios.post(
        'http://localhost:8080/api/trips/entertainment/insert',
        {
          etType,
          numUnits,
          etFloor,
          ageRestriction,
        },
        { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } }
      );
      setSuccess('Entertainment added successfully.');
      setTimeout(() => navigate('/adminhome'), 2000); // Navigate after 2 seconds
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add entertainment.');
    }
  };

  const handleHome = () => {
    navigate('/adminhome');
  };
  const handleInsertTrip = () => {
    navigate('/trip/insert');
  };
  const handleInsertRestaurant = () => {
    navigate('/restaurant/insert');
  };
  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  return (
    <Container>
      <Sidebar>
        <SidebarTitle>Admin Dashboard</SidebarTitle>
        <SidebarButton onClick={handleHome}>
          <FaHome /> Home
        </SidebarButton>
        <SidebarButton onClick={handleInsertTrip}>
          <FaShip /> Add Trip
        </SidebarButton>
        <SidebarButton onClick={handleInsertRestaurant}>
          <FaUtensils /> Add Restaurant
        </SidebarButton>
        <SidebarButton onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </SidebarButton>
      </Sidebar>

      <MainContent>
        <Title>Insert Entertainment</Title>
        <Form onSubmit={handleSubmit}>
          <Label htmlFor="etType">Entertainment Type</Label>
          <Select
            id="etType"
            value={etType}
            onChange={(e) => setEtType(e.target.value)}
            required
          >
            <option value="">Select Type</option>
            <option value="Movie">Movie</option>
            <option value="Concert">Concert</option>
            <option value="Play">Play</option>
            <option value="Other">Other</option>
          </Select>

          <Label htmlFor="numUnits">Number of Units</Label>
          <Input
            type="number"
            id="numUnits"
            value={numUnits}
            onChange={(e) => setNumUnits(e.target.value)}
            required
            min="1"
          />

          <Label htmlFor="etFloor">Entertainment Floor</Label>
          <Input
            type="number"
            id="etFloor"
            value={etFloor}
            onChange={(e) => setEtFloor(e.target.value)}
            required
            min="1"
          />

          <Label htmlFor="ageRestriction">Age Restriction</Label>
          <Input
            type="number"
            id="ageRestriction"
            value={ageRestriction}
            onChange={(e) => setAgeRestriction(e.target.value)}
            required
            min="0"
          />

          {error && <ErrorMessage>{error}</ErrorMessage>}
          {success && <SuccessMessage>{success}</SuccessMessage>}

          <Button type="submit">Add Entertainment</Button>
        </Form>
      </MainContent>
    </Container>
  );
};

export default InsertEntertainment;
