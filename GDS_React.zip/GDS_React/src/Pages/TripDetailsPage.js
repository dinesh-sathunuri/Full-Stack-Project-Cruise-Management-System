
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TripDetailsPage = ({ tripId }) => {
    const [tripDetails, setTripDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchTripDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/api/trips/${tripId}`);
                setTripDetails(response.data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchTripDetails();
    }, [tripId]);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div>
            <h1>Trip Details</h1>
            <h3>Start Port: {tripDetails.trip.startPort}</h3>
            <h3>End Port: {tripDetails.trip.endPort}</h3>
            <h3>Number of Nights: {tripDetails.trip.numNights}</h3>
            <h3>Start Date: {tripDetails.trip.startDate.toString()}</h3>
            <h3>End Date: {tripDetails.trip.endDate.toString()}</h3>

            <h2>Restaurants:</h2>
            <ul>
                {tripDetails.restaurants.map((restaurant) => (
                    <li key={restaurant.restaurantId}>
                        <h4>{restaurant.rtName} ({restaurant.rtType})</h4>
                        <p>Floor: {restaurant.rtFloor}</p>
                        <p>Opening Time: {new Date(restaurant.openingTime).toLocaleTimeString()}</p>
                        <p>Closing Time: {new Date(restaurant.closingTime).toLocaleTimeString()}</p>
                    </li>
                ))}
            </ul>

            <h2>Entertainment:</h2>
            <ul>
                {tripDetails.entertainments.map((entertainment) => (
                    <li key={entertainment.entertainmentId}>
                        <h4>{entertainment.etType}</h4>
                        <p>Number of Units: {entertainment.numUnits}</p>
                        <p>Floor: {entertainment.etFloor}</p>
                        <p>Age Restriction: {entertainment.ageRestriction}+</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default TripDetailsPage;