import React, { useState, useEffect } from 'react';
import { Pie } from 'react-chartjs-2'; // Pie chart for package popularity
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, Title);

const PackagePopularityGraph = () => {
  const [packagePopularity, setPackagePopularity] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch data for package popularity
  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch('http://localhost:8080/api/bookings/packages/popularity'); // Adjust API endpoint
        const data = await response.json();
        setPackagePopularity(data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching package popularity data:", error);
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Prepare data for the Pie chart
  const chartData = {
    labels: packagePopularity.map((data) => data.packageType), // Package types as labels
    datasets: [
      {
        label: 'Package Popularity',
        data: packagePopularity.map((data) => data.numPurchases), // Number of purchases for each package
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'], // Different colors for each segment
        hoverOffset: 4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'Package Popularity',
      },
    },
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (packagePopularity.length === 0) {
    return <div>No package popularity data available.</div>;
  }

  return (
    <div style={{ width: '50%', margin: '20px 0 20px 0', textAlign: 'left' }}>
      <h2>Package Popularity (Pie Chart)</h2>
      <Pie data={chartData} options={chartOptions} height={300} width={400} />
    </div>
  );
};

export default PackagePopularityGraph;
