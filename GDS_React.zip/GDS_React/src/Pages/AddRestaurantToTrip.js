import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import styled from "styled-components";
import { FaSave } from "react-icons/fa";

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f4f7fc;
  font-family: "Roboto", sans-serif;
`;

const MainContent = styled.div`
  padding: 40px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 600px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #007bff;
  color: white;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
  font-size: 28px;
  margin: 0;
  font-weight: 700;
  text-align: center;
`;


const FormGroup = styled.div`
  margin-bottom: 25px;
`;

const Label = styled.label`
  font-size: 18px;
  margin-bottom: 10px;
  font-weight: 600;
  color: #333;
`;

const Select = styled.select`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

const Input = styled.input`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

const Button = styled.button`
  padding: 12px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }
`;

const Message = styled.div`
  text-align: center;
  margin-top: 20px;
  font-size: 16px;
  color: ${(props) => (props.success ? "green" : "red")};
`;

const AddRestaurantToTrip = () => {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [restaurants, setRestaurants] = useState([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [mealType, setMealType] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [tripExists, setTripExists] = useState(true);

  useEffect(() => {
    // Fetch trip details to check if it exists
    fetch(`http://localhost:8080/api/trips/${tripId}`)
      .then((response) => {
        if (!response.ok) {
          setTripExists(false);
          throw new Error("Trip not found.");
        }
        return response.json();
      })
      .catch((error) => {
        setError(error.message);
      });

    // Fetch available restaurants
    fetch("http://localhost:8080/api/trips/restaurants")
      .then((response) => response.json())
      .then((data) => setRestaurants(data))
      .catch((error) => setError("Error fetching restaurants."));
  }, [tripId]);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate if all fields are selected
    if (!selectedRestaurant || !scheduleDate || !mealType) {
      setError("All fields are required.");
      return;
    }

    // Validate if the schedule date is in the past
    const currentDate = new Date();
    const selectedDate = new Date(scheduleDate);
    if (selectedDate < currentDate) {
      setError("The schedule date cannot be in the past.");
      return;
    }

    const requestData = {
      scheduleDate,
      mealType,
      tripId: parseInt(tripId),
      restaurantScheduleId: parseInt(selectedRestaurant),
    };

    // POST request to add the restaurant schedule to the trip
    fetch("http://localhost:8080/api/trips/Insert/triprestaurant", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(requestData),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to add restaurant schedule.");
        }
      })
      .then(() => {
        setSuccessMessage("Restaurant successfully added to the trip!");
        setTimeout(() => navigate(`/admintrip/${tripId}`), 2000);
      })
      .catch((error) => {
        console.error("Error adding restaurant to trip:", error);
        setError(error.message || "An unexpected error occurred.");
      });
  };

  if (!tripExists) {
    return <Message>{`Trip with ID ${tripId} does not exist.`}</Message>;
  }

  return (
    <Container>
      <MainContent>
        <Header>
          <Title>Add Restaurant to Trip</Title>
        </Header>

        {error && <Message>{error}</Message>}
        {successMessage && <Message success>{successMessage}</Message>}

        <form onSubmit={handleSubmit}>
          <FormGroup>
            <Label>Select Restaurant</Label>
            <Select
              value={selectedRestaurant}
              onChange={(e) => setSelectedRestaurant(e.target.value)}
            >
              <option value="">-- Choose a Restaurant --</option>
              {restaurants.map((restaurant) => (
                <option key={restaurant.restaurantId} value={restaurant.restaurantId}>
                  {restaurant.rtName} - {restaurant.rtType} (Floor: {restaurant.rtFloor})
                </option>
              ))}
            </Select>
          </FormGroup>

          <FormGroup>
            <Label>Schedule Date</Label>
            <Input
              type="date"
              value={scheduleDate}
              onChange={(e) => setScheduleDate(e.target.value)}
            />
          </FormGroup>

          <FormGroup>
            <Label>Meal Type</Label>
            <Select
              value={mealType}
              onChange={(e) => setMealType(e.target.value)}
            >
              <option value="">-- Choose a Meal Type --</option>
              <option value="Breakfast">Breakfast</option>
              <option value="Lunch">Lunch</option>
              <option value="Dinner">Dinner</option>
            </Select>
          </FormGroup>

          <Button type="submit">
              <FaSave style={{ marginRight: "10px" }} /> Add to Trip
            </Button>
        </form>
      </MainContent>
    </Container>
  );
};

export default AddRestaurantToTrip;
