import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

// Styled Components
const Container = styled.div`
  padding: 20px;
  background-color: #f4f7fc;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  font-family: 'Arial', sans-serif;
`;

const Title = styled.h1`
  font-size: 28px;
  margin-bottom: 30px;
  color: #333;
  text-align: center;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
  background: white;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 600px;
`;

const Input = styled.input`
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 14px;
  margin-bottom: 15px;
  width: 100%;
  box-sizing: border-box;

  &:focus {
    border-color: #4caf50;
    outline: none;
  }
`;

const Button = styled.button`
  padding: 12px 20px;
  background-color: ${(props) => (props.primary ? '#4caf50' : '#007bff')};
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  transition: all 0.3s ease;

  &:hover {
    background-color: ${(props) => (props.primary ? '#45a049' : '#0056b3')};
    transform: translateY(-2px);
  }

  &:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }

  margin-top: ${(props) => (props.inline ? '10px' : '20px')};
`;

const ErrorMessage = styled.div`
  color: #e74c3c;
  margin-top: 20px;
  text-align: center;
  font-size: 14px;
`;

const MemberBox = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #f9f9f9;
  padding: 15px;
  border-radius: 8px;
  width: 100%;
  max-width: 500px;
  margin-top: 20px;
`;

const MemberDetails = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 12px;
  background-color: #f1f1f1;
  border-radius: 6px;
  margin-bottom: 8px;
  font-size: 14px;
  font-weight: 500;
`;

const GroupSelection = styled.div`
  margin-top: 30px;
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  width: 100%;
  max-width: 600px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
`;

const GroupItem = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding: 10px;
  background-color: #f9f9f9;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;

  &:hover {
    background-color: #f1f1f1;
  }
`;

const GroupCreation = () => {
  const [groupName, setGroupName] = useState('');
  const [passengers, setPassengers] = useState([]);
  const [error, setError] = useState(null);
  const [newPassengerEmail, setNewPassengerEmail] = useState('');
  const [recentGroups, setRecentGroups] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const sessionId = Cookies.get('sessionId');
    if (!sessionId) {
      navigate('/login'); // Redirect to login if not authenticated
      return;
    }

    const fetchFirstPassenger = async () => {
      try {
        const response = await fetch(`http://localhost:8080/passenger/api/userdetails?email=${sessionId}`);
        if (!response.ok) throw new Error('Failed to fetch user details');

        const user = await response.json();
        const firstPassenger = {
          passengerId: user.passenger_id, 
          firstName: user.first_name,
          lastName: user.last_name,
          email: user.email,
          dateOfBirth: user.date_of_birth,
        };

        const storedPassengers = JSON.parse(localStorage.getItem('passengers')) || [];
        if (!storedPassengers.some((p) => p.email === firstPassenger.email)) {
          storedPassengers.unshift(firstPassenger);
          localStorage.setItem('firstPassengerId', firstPassenger.passengerId); // Save the first passenger's ID
        }

        setPassengers(storedPassengers);
        setGroupName(localStorage.getItem('groupName') || '');
      } catch (error) {
        console.error('Error fetching first passenger details:', error);
        setError('Error: Could not fetch first passenger details.');
      }
    };

    fetchFirstPassenger();
  }, [navigate]);

  useEffect(() => {
    if (groupName || passengers.length) {
      localStorage.setItem('groupName', groupName);
      localStorage.setItem('passengers', JSON.stringify(passengers));

      const aboveFiveCount = passengers.filter(passenger => calculateAge(passenger.dateOfBirth) > 5).length;
      localStorage.setItem('aboveFiveCount', aboveFiveCount);
    }
  }, [groupName, passengers]);

  useEffect(() => {
    const fetchRecentGroups = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/recent-groups'); // Adjust the endpoint as per your backend
        if (!response.ok) throw new Error('Failed to fetch recent groups');
        
        const groups = await response.json();
        setRecentGroups(groups);
      } catch (error) {
        console.error('Error fetching recent groups:', error);
      }
    };

    fetchRecentGroups();
  }, []);

  const calculateAge = (dateOfBirth) => {
    const dob = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  };

  const handleNewPassengerEmailChange = (e) => {
    setNewPassengerEmail(e.target.value);
  };

  const fetchPassengerDetailsByEmail = async (email) => {
    try {
      const response = await fetch(`http://localhost:8080/passenger/api/userdetails?email=${email}`);
      if (!response.ok) {
        alert(`${email} is not registered`);
        return;
      }

      const user = await response.json();
      const newPassenger = {
        passengerId: user.passenger_id, 
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
        dateOfBirth: user.date_of_birth,
      };

      // Check for duplicates
      if (passengers.some(p => p.email === newPassenger.email)) {
        setError(`Passenger with email ${newPassenger.email} already exists.`);
        return;
      }

      const age = calculateAge(newPassenger.dateOfBirth);
      setPassengers((prevPassengers) => [
        ...prevPassengers,
        { ...newPassenger, age }
      ]);

      setNewPassengerEmail('');
      setError(null);
    } catch (error) {
      console.error(`Error fetching details for email ${email}:`, error);
      setError('Error: Could not retrieve passenger details. Please try again.');
    }
  };

  const handlePassengerRemove = (index) => {
    if (index !== 0) {
      const updatedPassengers = passengers.filter((_, i) => i !== index);
      setPassengers(updatedPassengers);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate('/packages');
    
  };

  const handleGroupSelect = (group) => {
    setGroupName(group.name);
    setPassengers(group.passengers); // Populate passengers for the selected group
  };

  return (
    <Container>
      <Title>Create Group</Title>
      {error && <ErrorMessage>{error}</ErrorMessage>}
      <Form onSubmit={handleSubmit}>
        <Input
          type="text"
          placeholder="Enter group name"
          value={groupName}
          onChange={(e) => setGroupName(e.target.value)}
          required
        />
        <div>
          <h3>Group Members</h3>
          {passengers.map((passenger, index) => (
            <MemberBox key={index}>
              <MemberDetails>
                <span>{passenger.firstName} {passenger.lastName}</span>
                <span>{passenger.email}</span>
                <span>{calculateAge(passenger.dateOfBirth)} years old</span>
                {index !== 0 && (
                  <Button onClick={() => handlePassengerRemove(index)} inline>
                    Remove
                  </Button>
                )}
              </MemberDetails>
            </MemberBox>
          ))}
        </div>

        <Input
          type="email"
          value={newPassengerEmail}
          onChange={handleNewPassengerEmailChange}
          placeholder="Enter passenger email"
        />
        <Button onClick={() => fetchPassengerDetailsByEmail(newPassengerEmail)}>Add Passenger</Button>

        <Button type="submit" primary>Save Group</Button>
      </Form>

      {recentGroups.length > 0 && (
        <GroupSelection>
          <h3>Recently Used Groups</h3>
          {recentGroups.map((group, index) => (
            <GroupItem key={index} onClick={() => handleGroupSelect(group)}>
              <span>{group.name}</span>
              <span>{group.passengers.length} members</span>
            </GroupItem>
          ))}
        </GroupSelection>
      )}
    </Container>
  );
};

export default GroupCreation;
