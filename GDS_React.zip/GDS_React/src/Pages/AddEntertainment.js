import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";
import styled from "styled-components";
import { FaSave } from "react-icons/fa";

// Container styles for the page layout, using flexbox to center the content
const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  font-family: "Roboto", sans-serif;
  background-color: #f4f7fc;
`;

// Main content area with padding, centered content, and background
const MainContent = styled.div`
  padding: 40px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 600px;
`;

// Header section with background color, shadow, and margin
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  background-color: #007bff;
  color: white;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
`;

// Title for the page with bold styling
const Title = styled.h1`
  font-size: 28px;
  margin: 0;
  font-weight: 700;
  text-align: center;
`;

// Form container with spacing between form elements
const FormContainer = styled.div`
  display: flex;
  flex-direction: column;
`;

// Form group for each form field
const FormGroup = styled.div`
  margin-bottom: 25px;
  display: flex;
  flex-direction: column;
`;

// Label for form inputs, styled for clarity and readability
const Label = styled.label`
  font-size: 18px;
  margin-bottom: 10px;
  font-weight: 600;
  color: #333;
`;

// Select dropdown with border, padding, and hover effects
const Select = styled.select`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

// Input date field with padding and modern look
const Input = styled.input`
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

// Submit button with hover effects
const Button = styled.button`
  padding: 12px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  display: flex;
  align-items: center;
  justify-content: center;
`;

// Error message for form validation
const ErrorMessage = styled.div`
  color: red;
  font-size: 16px;
  margin-top: 20px;
  text-align: center;
`;

// Success message for successful submission
const SuccessMessage = styled.div`
  color: green;
  font-size: 16px;
  margin-top: 20px;
  text-align: center;
`;

// Main AddEntertainment component
const AddEntertainment = () => {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [entertainments, setEntertainments] = useState([]);
  const [selectedEntertainment, setSelectedEntertainment] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [tripExists, setTripExists] = useState(true);

  // Fetch trip and entertainment options
  useEffect(() => {
    // Fetch trip details to check if it exists
    axios
      .get(`http://localhost:8080/api/trips/${tripId}`)
      .then((response) => {
        if (!response.data) {
          setTripExists(false);
        }
      })
      .catch(() => {
        setTripExists(false);
      });

    // Fetch available entertainment
    axios
      .get("http://localhost:8080/api/trips/entertainment")
      .then((response) => {
        setEntertainments(response.data);
      })
      .catch(() => {
        setError("Failed to fetch entertainment options.");
      });
  }, [tripId]);

  const handleSubmit = (e) => {
    e.preventDefault();
  
    // Validate if all fields are selected
    if (!selectedEntertainment || !scheduleDate) {
      setError("All fields are required.");
      return;
    }
  
    // Check if the schedule date is not in the past
    const currentDate = new Date();
    const selectedDate = new Date(scheduleDate);
    if (selectedDate < currentDate) {
      setError("The schedule date cannot be in the past.");
      return;
    }
  
    const requestData = {
      schedule: scheduleDate,
      TripId: tripId,
      EntertainmentId: selectedEntertainment,
    };
  
    // Log the requestData to verify the values
    console.log("Request Data:", requestData);
  
    // Send POST request to add entertainment to the trip
    axios
      .post("http://localhost:8080/api/trips/Insert/tripentertainment", requestData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      .then(() => {
        setSuccessMessage("Entertainment successfully added to the trip!");
        setTimeout(() => navigate(`/admintrip/${tripId}`), 2000); // Redirect after success
      })
      .catch((error) => {
        setError(error.message || "An error occurred while adding entertainment.");
      });
  };
  
  if (!tripExists) {
    return <ErrorMessage>Trip with ID {tripId} does not exist.</ErrorMessage>;
  }

  return (
    <Container>
      <MainContent>
        <Header>
          <Title>Add Entertainment to Trip</Title>
          
        </Header>

        {error && <ErrorMessage>{error}</ErrorMessage>}
        {successMessage && <SuccessMessage>{successMessage}</SuccessMessage>}

        <FormContainer>
          <form onSubmit={handleSubmit}>
            <FormGroup>
              <Label>Select Entertainment</Label>
              <Select
                value={selectedEntertainment}
                onChange={(e) => setSelectedEntertainment(e.target.value)}
              >
                <option value="">-- Choose Entertainment --</option>
                {entertainments.map((entertainment) => (
                  <option key={entertainment.entertainmentId} value={entertainment.entertainmentId}>
                    {entertainment.etType} - {entertainment.numUnits} units
                  </option>
                ))}
              </Select>
            </FormGroup>

            <FormGroup>
              <Label>Schedule Date</Label>
              <Input
                type="date"
                value={scheduleDate}
                onChange={(e) => setScheduleDate(e.target.value)}
              />
            </FormGroup>

            <Button type="submit">
              <FaSave style={{ marginRight: "10px" }} /> Add to Trip
            </Button>
          </form>
        </FormContainer>
      </MainContent>
    </Container>
  );
};

export default AddEntertainment;
