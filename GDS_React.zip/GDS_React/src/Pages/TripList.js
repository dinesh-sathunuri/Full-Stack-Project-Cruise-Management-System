import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { FaSignOutAlt, FaInfoCircle, FaShip, FaUserCircle } from 'react-icons/fa';

const Container = styled.div`
  padding: 20px;
  background-color: #f4f7fc;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
  font-family: 'Arial', sans-serif;
`;

const Header = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 30px;
  background-color: #007bff;
  color: white;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  margin-bottom: 30px;
`;

const Title = styled.h1`
  font-size: 28px;
  margin: 0;
  font-weight: 600;
`;

const AccountContainer = styled.div`
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
  color: white;

  &:hover {
    opacity: 0.8;
  }
`;

const AccountMenu = styled.div`
  display: ${(props) => (props.show ? 'block' : 'none')};
  position: absolute;
  top: 50px;
  right: 0;
  background-color: white;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  overflow: hidden;
  width: 200px;
  z-index: 10;
`;

const AccountItem = styled.div`
  padding: 12px 20px;
  color: #333;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #f4f4f4;
  }
`;

const TripGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 25px;
  width: 100%;
  margin-top: 20px;
`;

const TripCard = styled.div`
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s ease;

  &:hover {
    transform: translateY(-5px);
  }
`;

const TripImage = styled.div`
  background: url('https://pbs.twimg.com/media/F7iSr7-WoAAqBAy?format=jpg&name=large') center/cover;
  height: 180px;
`;

const TripContent = styled.div`
  padding: 20px;
  text-align: center;
`;

const TripTitle = styled.h3`
  margin: 0;
  color: #007bff;
  font-size: 20px;
`;

const TripDetails = styled.p`
  color: #555;
  margin: 5px 0;
  font-size: 15px;
`;

const ButtonContainer = styled.div`
  display: flex;
  justify-content: space-around;
  padding: 15px;
  background-color: #f9f9f9;
  border-top: 1px solid #eee;
`;

const Button = styled.button`
  padding: 12px 20px;
  background-color: ${(props) => (props.primary ? '#007bff' : '#28a745')};
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 15px;
  transition: background-color 0.3s;

  &:hover {
    background-color: ${(props) => (props.primary ? '#0056b3' : '#218838')};
  }
`;

const LoadingMessage = styled.div`
  margin-top: 50px;
  font-size: 18px;
  color: #666;
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 16px;
  margin-top: 20px;
`;

const TripList = () => {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTrips = async () => {
      localStorage.removeItem('tripId'); 
      localStorage.removeItem('groupName'); 
      localStorage.removeItem('numPassengers'); 
      localStorage.removeItem('passengers'); 
      localStorage.removeItem('selectedPackages'); 
      localStorage.removeItem('selectedStateroomId'); 
      localStorage.removeItem('tripDetails'); 

      try {
        const response = await axios.get('http://localhost:8080/api/trips/list', {
          headers: {
            Authorization: localStorage.getItem('token'),
          },
        });
        setTrips(response.data);
      } catch (error) {
        setError('Failed to fetch trips. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTrips();
  }, []);

  const handleDetails = (tripId) => {
    navigate(`/trip/${tripId}`);
  };

  const handleBook = (tripId) => {
    localStorage.setItem('tripId', tripId);
    navigate(`/create-group`);
  };

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  const handleViewProfile = () => {
    navigate('/profile');
    setMenuVisible(false);
  };

  // const handleRecentGroups = () => {
  //   navigate('/recent-groups');
  //   setMenuVisible(false);
  // };

  const handleRecentBooking = () => {
    navigate('/recent-booking');
    setMenuVisible(false);
  };

  return (
    <Container>
      <Header>
        <Title>Available Trips</Title>
        <AccountContainer onClick={toggleMenu}>
          <FaUserCircle size={28} />
          <AccountMenu show={menuVisible}>
            <AccountItem onClick={handleViewProfile}>View Profile</AccountItem>
            {/* <AccountItem onClick={handleRecentGroups}>Recent Groups</AccountItem> */}
            <AccountItem onClick={handleRecentBooking}>Recent Booking</AccountItem>
            <AccountItem onClick={handleLogout}>Logout</AccountItem>
          </AccountMenu>
        </AccountContainer>
      </Header>

      {loading ? (
        <LoadingMessage>Loading trips...</LoadingMessage>
      ) : error ? (
        <ErrorMessage>{error}</ErrorMessage>
      ) : (
        <TripGrid>
          {trips.map((trip) => (
            <TripCard key={trip.tripId}>
              <TripImage />
              <TripContent>
                <TripTitle>{trip.startPort} to {trip.endPort}</TripTitle>
                <TripDetails><strong>Duration:</strong> {trip.numNights} nights</TripDetails>
                <TripDetails><strong>From:</strong> {new Date(trip.startDate).toLocaleDateString()}</TripDetails>
                <TripDetails><strong>To:</strong> {new Date(trip.endDate).toLocaleDateString()}</TripDetails>
              </TripContent>
              <ButtonContainer>
                <Button onClick={() => handleDetails(trip.tripId)} primary>
                  <FaInfoCircle /> Details
                </Button>
                <Button onClick={() => handleBook(trip.tripId)}>
                  <FaShip /> Book
                </Button>
              </ButtonContainer>
            </TripCard>
          ))}
        </TripGrid>
      )}
    </Container>
  );
};

export default TripList;
