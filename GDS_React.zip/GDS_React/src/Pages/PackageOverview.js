import React, { useEffect, useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

const Container = styled.div`
  padding: 20px;
  background-color: #eef3f8;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 100vh;
`;

const Title = styled.h1`
  font-size: 24px;
  margin: 0 0 20px 0;
  color: #333;
`;

const Loader = styled.div`
  margin: 30px 0;
  font-size: 18px;
  color: #4caf50;
`;

const ErrorMessage = styled.p`
  color: red;
  font-size: 18px;
  margin-top: 20px;
`;

const GridContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  width: 100%;
`;

const ItemCard = styled.div`
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s;
  display: flex;
  flex-direction: column;
  padding: 15px;
  cursor: pointer;

  &:hover {
    transform: translateY(-5px);
  }

  border: ${(props) => (props.isSelected ? '2px solid #007bff' : 'none')};
`;

const ItemTitle = styled.h3`
  margin: 0;
  color: #333;
`;

const ItemDetails = styled.p`
  color: #666;
  margin: 5px 0;
  font-size: 14px;
`;

const PackageSectionTitle = styled.h2`
  margin: 20px 0 10px 0;
  font-size: 20px;
  color: #444;
`;

const QuantityContainer = styled.div`
  display: flex;
  align-items: center;
  margin-top: 10px;
`;

const QuantityButton = styled.button`
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 5px 10px;
  cursor: pointer;
  margin: 0 5px;
  
  &:disabled {
    background-color: #ccc;
  }
`;

const QuantityInput = styled.input`
  width: 40px;
  text-align: center;
`;

const StateroomSectionTitle = styled.h2`
  font-size: 20px;
  color: #444;
  margin: 20px 0;
`;

const BookButton = styled.button`
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 16px;
  margin-top: 30px;
  cursor: pointer;

  &:disabled {
    background-color: #ccc;
  }
`;

const PackageOverview = () => {
  const [packages, setPackages] = useState([]);
  const [staterooms, setStaterooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedStateroom, setSelectedStateroom] = useState(null);
  const [quantities, setQuantities] = useState({});
  const tripId = localStorage.getItem('tripId');
  const navigate = useNavigate();
  const fiveCount = parseInt(localStorage.getItem('aboveFiveCount'));  // Fetch FiveCount from localStorage

  useEffect(() => {
    const fetchPackagesAndStaterooms = async () => {
      setLoading(true);
      setError(null);

      try {
        const packageResponse = await axios.get(`http://localhost:8080/api/trips/packages`);
        setPackages(packageResponse.data);

        const stateroomResponse = await axios.get(`http://localhost:8080/api/trips/staterooms/details?tripId=${tripId}`);
        setStaterooms(stateroomResponse.data);
      } catch (err) {
        setError('Error fetching data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    if (tripId) {
      fetchPackagesAndStaterooms();
    } else {
      setError('Trip ID not found in local storage.');
      setLoading(false);
    }
  }, [tripId]);

  const handleStateroomSelect = (stateroomPriceId) => {
    setSelectedStateroom(stateroomPriceId);
  };

  const handleQuantityChange = (packageId, value) => {
    setQuantities((prev) => ({
      ...prev,
      [packageId]: Math.max(0, value), // Prevent negative quantities
    }));
  };

  const handleBookClick = () => {
    const selectedPackages = Object.keys(quantities)
      .filter((pkgId) => quantities[pkgId] > 0)
      .map((pkgId) => ({
        packageId: pkgId,
        quantity: quantities[pkgId],
      }));

    if (selectedPackages.length > 0 && selectedStateroom) {
      // Store selected packages and stateroom in local storage
      localStorage.setItem('selectedPackages', JSON.stringify(selectedPackages));
      localStorage.setItem('selectedStateroomId', selectedStateroom);
      // eslint-disable-next-line no-undef
      navigate('/Booking');
    } else {
      alert('Please select a stateroom and add at least one package.');
    }
  };

  const isBookButtonDisabled = !selectedStateroom || Object.values(quantities).every((qty) => qty <= 0);

  return (
    <Container>
      <Title>Available Staterooms</Title>
      {loading && <Loader>Loading staterooms and packages...</Loader>}
      {error && <ErrorMessage>{error}</ErrorMessage>}

      {!loading && !error && (
        <>
          {/* Staterooms Section */}
          <StateroomSectionTitle>Select a Stateroom</StateroomSectionTitle>
          <GridContainer>
            {staterooms
              .filter((room) => room.numBeds >= fiveCount && room.num_Units > 0) 
              .map((room) => (
                <ItemCard
                  key={room.stateroomPriceId}
                  onClick={() => handleStateroomSelect(room.stateroomPriceId)}
                  isSelected={selectedStateroom === room.stateroomPriceId}
                >
                  <ItemTitle>{room.type_name}</ItemTitle>
                  <ItemDetails>Size: {room.sizeSqft} sqft</ItemDetails>
                  <ItemDetails>Beds: {room.numBeds}</ItemDetails>
                  <ItemDetails>Bathrooms: {room.numBathrooms}</ItemDetails>
                  <ItemDetails>Balcony: {room.balcony}</ItemDetails>
                  <ItemDetails>Cruise Ship Side: {room.cruiseShipSide}</ItemDetails>
                  <ItemDetails>Location Side: {room.locationSide}</ItemDetails>
                  <ItemDetails>Price per Night: ${room.pricePerNight}</ItemDetails>
                </ItemCard>
              ))}
          </GridContainer>

          <PackageSectionTitle>Available Packages</PackageSectionTitle>
          <GridContainer>
            {/* Packages Section */}
            {packages.map((pkg) => (
              <ItemCard key={pkg.packageId}>
                <ItemTitle>{pkg.pkType}</ItemTitle>
                <ItemDetails>Price: ${pkg.price} USD</ItemDetails>
                <ItemDetails>Duration: {pkg.duration} days</ItemDetails>

                {/* Quantity Selection */}
                <QuantityContainer>
                  <QuantityButton
                    onClick={() => handleQuantityChange(pkg.packageId, (quantities[pkg.packageId] || 0) - 1)}
                    disabled={(quantities[pkg.packageId] || 0) <= 0}
                  >
                    -
                  </QuantityButton>
                  <QuantityInput
                    type="number"
                    value={quantities[pkg.packageId] || 0}
                    onChange={(e) => handleQuantityChange(pkg.packageId, parseInt(e.target.value) || 0)}
                  />
                  <QuantityButton
                    onClick={() => handleQuantityChange(pkg.packageId, (quantities[pkg.packageId] || 0) + 1)}
                  >
                    +
                  </QuantityButton>
                </QuantityContainer>
              </ItemCard>
            ))}
          </GridContainer>

          <BookButton onClick={handleBookClick} disabled={isBookButtonDisabled}>
            Book Now
          </BookButton>
        </>
      )}
    </Container>
  );
};

export default PackageOverview;
