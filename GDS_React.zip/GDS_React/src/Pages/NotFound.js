// NotFound.js
import React from 'react';
import styled from 'styled-components';

const NotFoundContainer = styled.div`
  text-align: center;
  padding: 50px;
  background-color: #eef3f8;
`;

const NotFoundTitle = styled.h1`
  font-size: 48px;
  color: #ff0000;
`;

const NotFoundMessage = styled.p`
  font-size: 24px;
`;

const NotFound = () => {
  return (
    <NotFoundContainer>
      <NotFoundTitle>404 - Page Not Found</NotFoundTitle>
      <NotFoundMessage>The page you are looking for does not exist.</NotFoundMessage>
    </NotFoundContainer>
  );
};

export default NotFound;