import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { FaHome, FaSignOutAlt, FaUtensils, FaTheaterMasks } from 'react-icons/fa';

const Container = styled.div`
  display: flex;
  min-height: 100vh;
  font-family: 'Roboto', sans-serif;
`;

const Sidebar = styled.div`
  width: 225px;
  background: linear-gradient(180deg, #007bff, #0056b3);
  padding: 20px;
  color: white;
  display: flex;
  flex-direction: column;
  position: fixed;
  height: 100%;
  top: 0;
  left: 0;
  box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
`;

const SidebarTitle = styled.h2`
  font-size: 26px;
  font-weight: 700;
  margin-bottom: 40px;
  color: #fff;
`;

const SidebarButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  text-align: left;
  padding: 12px 18px;
  cursor: pointer;
  margin-bottom: 20px;
  width: 100%;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.3s;

  &:hover {
    background-color: #0056b3;
    transform: scale(1.05);
  }

  & svg {
    margin-right: 10px;
  }
`;

const MainContent = styled.div`
  margin-left: 250px;
  padding: 20px;
  flex-grow: 1;
  background-color: #f4f7fc;
`;

const Title = styled.h1`
  text-align: center;
  color: #007bff;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`;

const Label = styled.label`
  font-size: 16px;
  color: #333;
`;

const Select = styled.select`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Input = styled.input`
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
`;

const Button = styled.button`
  padding: 10px;
  font-size: 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const ErrorMessage = styled.div`
  color: red;
  font-size: 14px;
  margin-top: 10px;
`;

const SuccessMessage = styled.div`
  color: green;
  font-size: 14px;
  margin-top: 10px;
`;

const InsertTrip = () => {
  const [ports, setPorts] = useState([]);
  const [startPort, setStartPort] = useState('');
  const [endPort, setEndPort] = useState('');
  const [numNights, setNumNights] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPorts = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/trips/port/list', {
          headers: { Authorization: localStorage.getItem('token') },
        });
        setPorts(response.data);
      } catch (err) {
        setError('Failed to fetch ports.');
      }
    };

    fetchPorts();
  }, []);

  // Function to calculate the endDate based on startDate and numNights
  const calculateEndDate = (start, nights) => {
    const startDate = new Date(start);
    startDate.setDate(startDate.getDate() + parseInt(nights)); // Add numNights to startDate
    return startDate.toISOString().split('T')[0]; // Format it as YYYY-MM-DD
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError('');
    setSuccess('');

    // Validate start and end ports
    if (startPort === endPort) {
      setError('Start port and end port cannot be the same.');
      return;
    }

    // Validate dates
    if (new Date(startDate) >= new Date(endDate)) {
      setError('Start date must be before end date.');
      return;
    }

    try {
      const response = await axios.post(
        'http://localhost:8080/api/trips/insert',
        { startPort, endPort, numNights, startDate, endDate },
        { headers: { Authorization: localStorage.getItem('token') } }
      );
      setSuccess('Trip created successfully.');
      setTimeout(() => navigate('/adminhome'), 2000); // Navigate after 2 seconds
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create trip.');
    }
  };

  // Update endDate whenever numNights or startDate changes
  useEffect(() => {
    if (startDate && numNights) {
      setEndDate(calculateEndDate(startDate, numNights));
    }
  }, [startDate, numNights]);

  const handleHome = () => {
    navigate('/adminhome');
  };

  const handleInsertRestaurant = () => {
    navigate('/restaurant/insert');
  };

  const handleInsertEntertainment = () => {
    navigate('/entertainment/insert');
  };
  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  return (
    <Container>
      <Sidebar>
        <SidebarTitle>Admin Dashboard</SidebarTitle>
        <SidebarButton onClick={handleHome}>
          <FaHome /> Home
        </SidebarButton>
        <SidebarButton onClick={handleInsertRestaurant}>
          <FaUtensils /> Add Restaurant
        </SidebarButton>
        <SidebarButton onClick={handleInsertEntertainment}>
          <FaTheaterMasks /> Add Entertainment
        </SidebarButton>
        <SidebarButton onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </SidebarButton>
      </Sidebar>

      <MainContent>
        <Title>Insert Trip</Title>
        <Form onSubmit={handleSubmit}>
          <Label htmlFor="startPort">Start Port</Label>
          <Select
            id="startPort"
            value={startPort}
            onChange={(e) => setStartPort(e.target.value)}
            required
          >
            <option value="">Select a start port</option>
            {ports.map((port) => (
              <option key={port.portId} value={port.portId}>
                {port.portName}
              </option>
            ))}
          </Select>

          <Label htmlFor="endPort">End Port</Label>
          <Select
            id="endPort"
            value={endPort}
            onChange={(e) => setEndPort(e.target.value)}
            required
          >
            <option value="">Select an end port</option>
            {ports.map((port) => (
              <option key={port.portId} value={port.portId}>
                {port.portName}
              </option>
            ))}
          </Select>

          <Label htmlFor="numNights">Number of Nights</Label>
          <Input
            type="number"
            id="numNights"
            value={numNights}
            onChange={(e) => setNumNights(e.target.value)}
            required
            min="1"
          />

          <Label htmlFor="startDate">Start Date</Label>
          <Input
            type="date"
            id="startDate"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            required
          />

          <Label htmlFor="endDate">End Date</Label>
          <Input
            type="date"
            id="endDate"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            required
            disabled // Disable editing end date manually
          />

          {error && <ErrorMessage>{error}</ErrorMessage>}
          {success && <SuccessMessage>{success}</SuccessMessage>}

          <Button type="submit">Create Trip</Button>
        </Form>
      </MainContent>
    </Container>
  );
};

export default InsertTrip;
