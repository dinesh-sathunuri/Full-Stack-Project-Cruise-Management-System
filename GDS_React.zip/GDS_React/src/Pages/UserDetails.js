import React, { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";

const UserDetails = () => {
  const [userDetails, setUserDetails] = useState(null);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const fetchUserDetails = async () => {
    setError("");
    setUserDetails(null);
    const email = Cookies.get("sessionId");

    if (!email) {
      setError("No session found. Please log in.");
      return;
    }

    try {
      const response = await axios.get("http://localhost:8080/passenger/api/userdetails", {
        params: { email },
      });
      setUserDetails(response.data);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        setError("User not found.");
      } else {
        setError("An error occurred while fetching user details.");
      }
    }
  };

  const saveUserDetails = async () => {
    setError("");

    try {
      const response = await axios.put("http://localhost:8080/passenger/api/update-user", userDetails);
      if (response.status === 200) {
        setIsEditing(false);
        alert("User details updated successfully!");
        fetchUserDetails(); // Refresh user details
      } else {
        setError("Failed to update user details. Please try again.");
      }
    } catch (err) {
      setError("An error occurred while updating user details.");
    }
  };

  useEffect(() => {
    fetchUserDetails();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserDetails({ ...userDetails, [name]: value });
  };

  const renderUserDetails = () => {
    const { id, ...details } = userDetails || {};  // Exclude 'id' from user details
    return (
      <>
        <div style={styles.detailItem}>
          <strong>First Name:</strong> {details.first_name || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Last Name:</strong> {details.last_name || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Email:</strong> {details.email || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Date of Birth:</strong> {details.date_of_birth || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Street Address:</strong> {details.street_address || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>City:</strong> {details.city || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>State:</strong> {details.state || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Zip Code:</strong> {details.zip_code || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Country:</strong> {details.country || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Gender:</strong> {details.gender || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Nationality:</strong> {details.nationality || "N/A"}
        </div>
        <div style={styles.detailItem}>
          <strong>Phone:</strong> {details.phone || "N/A"}
        </div>
      </>
    );
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>User Details</h1>
      {error && <p style={styles.error}>{error}</p>}
      {userDetails ? (
        <div style={styles.details}>
          <h3 style={styles.userInfoHeader}>User Information</h3>
          {isEditing ? (
            <>
              <div style={styles.editFields}>
                <input
                  type="text"
                  name="first_name"
                  value={userDetails.first_name}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="First Name"
                />
                <input
                  type="text"
                  name="last_name"
                  value={userDetails.last_name}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Last Name"
                />
                <input
                  type="email"
                  name="email"
                  value={userDetails.email}
                  readOnly
                  style={styles.input}
                  placeholder="Email"
                />
                <input
                  type="date"
                  name="date_of_birth"
                  value={userDetails.date_of_birth}
                  onChange={handleChange}
                  style={styles.input}
                />
                <input
                  type="text"
                  name="street_address"
                  value={userDetails.street_address || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Street Address"
                />
                <input
                  type="text"
                  name="city"
                  value={userDetails.city || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="City"
                />
                <input
                  type="text"
                  name="state"
                  value={userDetails.state || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="State"
                />
                <input
                  type="text"
                  name="zip_code"
                  value={userDetails.zip_code || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Zip Code"
                />
                <input
                  type="text"
                  name="country"
                  value={userDetails.country || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Country"
                />
                <input
                  type="text"
                  name="gender"
                  value={userDetails.gender || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Gender"
                />
                <input
                  type="text"
                  name="nationality"
                  value={userDetails.nationality || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Nationality"
                />
                <input
                  type="text"
                  name="phone"
                  value={userDetails.phone || ""}
                  onChange={handleChange}
                  style={styles.input}
                  placeholder="Phone"
                />
                <div style={styles.buttonContainer}>
                  <button onClick={saveUserDetails} style={styles.saveButton}>
                    Save
                  </button>
                  <button onClick={() => setIsEditing(false)} style={styles.cancelButton}>
                    Cancel
                  </button>
                </div>
              </div>
            </>
          ) : (
            <>
              <div style={styles.readOnlyFields}>
                {renderUserDetails()}
              </div>
              <button onClick={() => setIsEditing(true)} style={styles.editButton}>
                Edit
              </button>
            </>
          )}
        </div>
      ) : (
        <p>Loading user details...</p>
      )}
    </div>
  );
};

// Inline styles
const styles = {
  container: {
    maxWidth: "700px",
    margin: "50px auto",
    padding: "20px",
    borderRadius: "8px",
    backgroundColor: "#fff",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  header: {
    textAlign: "center",
    color: "#333",
    marginBottom: "20px",
    fontSize: "24px",
  },
  error: {
    color: "red",
    textAlign: "center",
    marginBottom: "15px",
  },
  details: {
    backgroundColor: "#f9f9f9",
    padding: "20px",
    borderRadius: "4px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },
  userInfoHeader: {
    color: "#007bff",
    marginBottom: "15px",
  },
  editFields: {
    display: "flex",
    flexDirection: "column",
  },
  readOnlyFields: {
    marginBottom: "20px",
    padding: "10px",
  },
  detailItem: {
    marginBottom: "10px",
  },
  input: {
    marginBottom: "12px",
    padding: "10px",
    width: "100%",
    borderRadius: "4px",
    border: "1px solid #8ae1fc",
    fontSize: "14px",
  },
  buttonContainer: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: "20px",
  },
  saveButton: {
    padding: "12px 20px",
    backgroundColor: "#28a745",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  cancelButton: {
    padding: "12px 20px",
    backgroundColor: "#dc3545",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  editButton: {
    padding: "12px 20px",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginTop: "20px",
  },
};

export default UserDetails;
